<div id="kt_header" class="header" data-kt-sticky="true" data-kt-sticky-name="header"
  data-kt-sticky-offset="{default: '200px', lg: '300px'}">
  <!--begin::Container-->
  <div class="container-fluid d-flex align-items-stretch justify-content-between">
    <!--begin::Logo bar-->
    <div class="d-flex align-items-center flex-grow-1 flex-lg-grow-0">
      <!--begin::Aside Toggle-->
      <div class="d-flex align-items-center d-lg-none">
        <div class="btn btn-icon btn-active-color-primary ms-n2 me-1" id="kt_aside_toggle">
          <!--begin::Svg Icon | path: icons/duotune/abstract/abs015.svg-->
          <span class="svg-icon svg-icon-2x">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
              <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z"
                fill="black"></path>
              <path opacity="0.3"
                d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z"
                fill="black"></path>
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
      </div>
      <!--end::Aside Toggle-->
      <!--begin::Logo-->
      <a href="" class="d-lg-none">
        <img alt="Logo" src="static/picture/logo-compact.svg" class="mh-40px" />
      </a>
      <!--end::Logo-->
      <!--begin::Aside toggler-->
      <div class="btn btn-icon w-auto ps-0 btn-active-color-primary d-none d-lg-inline-flex me-2 me-lg-5"
        data-kt-toggle="true" data-kt-toggle-state="active" data-kt-toggle-target="body"
        data-kt-toggle-name="aside-minimize">
        <!--begin::Svg Icon | path: icons/duotune/arrows/arr060.svg-->
        <span class="svg-icon svg-icon-2 rotate-180">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
            <path d="M9.60001 11H21C21.6 11 22 11.4 22 12C22 12.6 21.6 13 21 13H9.60001V11Z" fill="black"></path>
            <path
              d="M6.2238 13.2561C5.54282 12.5572 5.54281 11.4429 6.22379 10.7439L10.377 6.48107C10.8779 5.96697 11.75 6.32158 11.75 7.03934V16.9607C11.75 17.6785 10.8779 18.0331 10.377 17.519L6.2238 13.2561Z"
              fill="black"></path>
            <rect opacity="0.3" x="2" y="4" width="2" height="16" rx="1" fill="black"></rect>
          </svg>
        </span>
        <!--end::Svg Icon-->
      </div>
      <!--end::Aside toggler-->
    </div>
    <!--end::Logo bar-->
    <!--begin::Topbar-->
    <div class="d-flex align-items-stretch justify-content-between flex-lg-grow-1">
      <!--begin::Search-->
      <div class="d-flex align-items-stretch">
        <!--begin::Search-->
        <div class="d-flex align-items-center w-lg-400px" data-kt-search-keypress="true" data-kt-search-min-length="2"
          data-kt-search-enter="enter" data-kt-search-layout="menu" data-kt-search-responsive="lg"
          data-kt-menu-trigger="auto" data-kt-menu-permanent="true" data-kt-menu-placement="bottom-start">
          <!--begin::Form-->
          <form class="d-none d-lg-block w-100 position-relative mb-5 mb-lg-0"
            autocomplete="off">
            <!--begin::Hidden input(Added to disable form autocomplete)-->
            <input type="hidden" />
            <!--end::Hidden input-->
            <!--begin::Icon-->
            <!--begin::Svg Icon | path: icons/duotune/general/gen021.svg-->
            <span class="svg-icon svg-icon-2 svg-icon-gray-500 position-absolute top-50 translate-middle-y ms-0">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1"
                  transform="rotate(45 17.0365 15.1223)" fill="black"></rect>
                <path
                  d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z"
                  fill="black"></path>
              </svg>
            </span>
            <!--end::Svg Icon-->
            <!--end::Icon-->
            <!--begin::Input-->
            <input type="text" class="form-control form-control-flush ps-10" placeholder="Search..." />
            <!--end::Input-->
            <!--begin::Spinner-->
            <span class="position-absolute top-50 end-0 translate-middle-y lh-0 d-none me-1"
              data-kt-search-element="spinner">
              <span class="spinner-border h-15px w-15px align-middle text-gray-400"></span>
            </span>
            <!--end::Spinner-->
            <!--begin::Reset-->
            <span
              class="btn btn-flush btn-icon-gray-600 btn-active-color-primary position-absolute top-50 end-0 translate-middle-y lh-0 d-none"
              data-kt-search-element="clear">
              <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
              <span class="svg-icon svg-icon-1 me-0">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                  <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)"
                    fill="black"></rect>
                  <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black">
                  </rect>
                </svg>
              </span>
              <!--end::Svg Icon-->
            </span>
            <!--end::Reset-->
          </form>
          <!--end::Form-->
        </div>
        <!--end::Search-->
      </div>
      <!--end::Search-->
      <!--begin::Toolbar wrapper-->
      <div class="d-flex align-items-stretch flex-shrink-0">
        <!-- 邮件按钮 - 开始 -->
        <div id="gdBtn" class="d-flex align-items-center ms-1 ms-lg-3">
          <!--begin::Menu wrapper-->
          <div class="btn btn-icon btn-active-light-primary position-relative w-30px h-30px w-md-40px h-md-40px">
            <!--begin::Svg Icon | path: icons/duotune/communication/com012.svg-->
            <span class="svg-icon svg-icon-1">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path opacity="0.3" d="M21 18H3C2.4 18 2 17.6 2 17V7C2 6.4 2.4 6 3 6H21C21.6 6 22 6.4 22 7V17C22 17.6 21.6 18 21 18Z" fill="currentColor"/>
                <path d="M11.4 13.5C11.8 13.8 12.3 13.8 12.6 13.5L21.6 6.30005C21.4 6.10005 21.2 6 20.9 6H2.99998C2.69998 6 2.49999 6.10005 2.29999 6.30005L11.4 13.5Z" fill="currentColor"/>
              </svg>
            </span>
            <!--end::Svg Icon-->
            <span id="workOrderDot" style="display:none;" class="bullet bullet-dot bg-success h-6px w-6px position-absolute translate-middle top-0 start-50 animation-blink"></span>
          </div>
          <!--end::Menu wrapper-->
        </div>
        <!-- 邮件按钮 - 结束 -->
        <!--begin::User-->
        <div class="d-flex align-items-center ms-1 ms-lg-3" id="kt_header_user_menu_toggle">
          <!--begin::Menu wrapper-->
          <div class="cursor-pointer symbol symbol-35px symbol-lg-35px" data-kt-menu-trigger="click"
            data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
            <img alt="Pic" src="http://q2.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['user'];?>&spec=100" />
          </div>
          <!--begin::Menu-->
          <div
            class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-275px"
            data-kt-menu="true">
            <!--begin::Menu item-->
            <div class="menu-item px-3">
              <div class="menu-content d-flex align-items-center px-3">
                <!--begin::Avatar-->
                <div class="symbol symbol-50px me-5">
                  <img alt="Logo" src="http://q2.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['user'];?>&spec=100" />
                </div>
                <!--end::Avatar-->
                <!--begin::Username-->
                <div class="d-flex flex-column">
                  <div class="fw-bolder d-flex align-items-center fs-5">
                  <?=$userrow['name'];?>
                    <span class="badge badge-light-success fw-bolder fs-8 px-2 py-1 ms-2">UID：<?=$userrow['uid'];?></span>
                  </div>
                  <a href="javascript:;" class="fw-bold text-muted text-hover-primary fs-7"><?=$userrow['user'];?>@qq.com</a>
                </div>
                <!--end::Username-->
              </div>
            </div>
            <!--end::Menu item-->
            <!--begin::Menu separator-->
            <div class="separator my-2"></div>
            <!--end::Menu separator-->
            <!--begin::Menu item-->
            <div class="menu-item px-5">
              <a href="./index" class="menu-link px-5">用户中心</a>
            </div>
            <!--end::Menu item-->
            <?php if($conf['sjqykg']==1){?>
            <!--begin::Menu item-->
            <div class="menu-item px-5 my-1">
              <a id="sjqy" href="javascript:;" class="menu-link px-5">上级迁移</a>
            </div>
            <!--end::Menu item-->
            <?php } ?>
            <!--begin::Menu item-->
            <div class="menu-item px-5">
              <a href="./passwd" class="menu-link px-5">
                <span class="menu-text">修改密码</span>
                <span class="menu-badge">
                  <span class="badge badge-light-danger badge-circle fw-bolder fs-7">NEW</span>
                </span>
              </a>
            </div>
            <!--end::Menu item-->
            <!--begin::Menu separator-->
            <div class="separator my-2"></div>
            <!--end::Menu separator-->
            <!--begin::Menu item-->
            <div class="menu-item px-5">
              <a href="./charge" class="menu-link px-5">联系上级</a>
            </div>
            <!--end::Menu item-->
            <!--begin::Menu item-->
            <div class="menu-item px-5">
              <a id="logout" href="javascript:;" class="menu-link px-5">退出登录</a>
            </div>
            <!--end::Menu item-->
            <!--begin::Menu separator-->
            <div class="separator my-2"></div>
            <!--end::Menu separator-->
            <!--begin::Menu item-->
            <div class="menu-item px-5">
              <div class="menu-content px-5">
                <label class="form-check form-switch form-check-custom form-check-solid pulse pulse-success"
                  for="kt_user_menu_dark_mode_toggle">
                  <input class="form-check-input w-30px h-20px" type="checkbox" value="1" name="mode" />
                  <span class="pulse-ring ms-n1"></span>
                  <span class="form-check-label text-gray-600 fs-7">暗夜模式</span>
                </label>
              </div>
            </div>
            <!--end::Menu item-->
          </div>
          <!--end::Menu-->
          <!--end::Menu wrapper-->
        </div>
        <!--end::User -->
      </div>
      <!--end::Toolbar wrapper-->
    </div>
    <!--end::Topbar-->
  </div>
  <!--end::Container-->
</div>