<!DOCTYPE html>
<html lang="zh">
<?php $pagename="支付列表"; ?>
<!-- 头部 - 开始 -->
<?php
require_once('./head.php');
if($userrow['uid']!=1){exit("<script language='javascript'>window.location.href='./404';</script>");}
?>
<!-- 头部 - 结束 -->

<!--begin::Body-->
<body id="kt_body"
  class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled aside-fixed aside-default-enabled">

  <!--begin::Root-->
  <div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="page d-flex flex-row flex-column-fluid">
      <!--侧边栏 - 开始-->
      <?php include('./aside.php'); ?>
      <!--侧边栏 - 结束-->
      <!--begin::Wrapper-->
      <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
        <!--页面头部 - 开始-->
        <?php include('./header.php'); ?>
        <!--页面头部 - 结束-->
        <!--页面主内容 - 开始-->
        <div class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
          <!--begin::Toolbar-->
          <div class="toolbar" id="kt_toolbar">
            <div class="container-fluid d-flex flex-stack flex-wrap flex-sm-nowrap">
              <!--begin::Info-->
              <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                <!--begin::Title-->
                <h1 class="text-dark fw-bolder my-1 fs-2">支付列表</h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb fw-bold fs-base my-1">
                  <li class="breadcrumb-item text-muted">
                    <a href="./index" class="text-muted text-hover-primary">首页</a>
                  </li>
                  <li class="breadcrumb-item text-muted">系统管理</li>
                  <li class="breadcrumb-item text-dark">支付列表</li>
                </ul>
                <!--end::Breadcrumb-->
              </div>
              <!--end::Info-->
              <!--begin::Actions-->
              <div class="d-flex align-items-center flex-nowrap text-nowrap py-1">
                <a href="JavaScript:;" class="btn bg-body btn-color-gray-700 btn-active-primary me-4" data-bs-toggle="modal" data-bs-target="#modal_usernotice">站点公告</a>
                <a href="JavaScript:;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_tcgonggao">重要通知</a>
              </div>
              <!--end::Actions-->
            </div>
          </div>
          <!--end::Toolbar-->
          <!--begin::Post-->
          <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div class="container-xxl">
              <!--begin::Card-->
              <div class="card card-flush">
                <!--begin::Card header-->
                <div class="card-header mt-6">
                  <!--begin::Card title-->
                  <div class="card-title flex-column">
                    <h2 class="fw-boldest mb-2">支付列表</h2>
                    <div class="fs-6 fw-bold text-gray-400">展示本站所有的支付列表</div>
                  </div>
                  <!--end::Card title-->
                </div>
                <!--end::Card header-->
                <!--begin::Card body-->
                <?php 
                  $result=$DB->count("select count(*) from qingka_wangke_pay");
                  if($result<=0) {
                ?>
                  <div class="card-body pt-0">
                    <div class="text-center px-5">
                      <img src="static/picture/20.png" alt="" class="mw-100 mh-325px">
                      <h1 class="fw-bold mt-5" style="color: #A3A3C7">暂无数据</h1>
                    </div>
                  </div>
                <?php } else { ?>
                <div class="card-body pt-0">
                  <div class="table-responsive">
                    <!--begin::Table-->
                    <table class="table align-middle table-row-dashed fs-6 gy-5 mb-0">
                      <!--begin::Table head-->
                      <thead>
                        <!--begin::Table row-->
                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                          <th class="min-w-50px">ID</th>
                          <th class="min-w-50px">订单号</th>
													<th class="min-w-50px">用户UID</th>
                          <th class="min-w-50px">支付方式</th>
                          <th class="min-w-80px">订单标题</th>
                          <th class="min-w-80px">订单金额</th>
													<th class="min-w-125px">创建时间</th>
													<th class="min-w-125px">支付时间</th>
                          <th class="text-end min-w-50px">支付状态</th>
                        </tr>
                        <!--end::Table row-->
                      </thead>
                      <!--end::Table head-->
                      <!--begin::Table body-->
                      <tbody class="fw-bold text-gray-600">
                        <?php 
                        $a=$DB->query("select * from qingka_wangke_pay order by oid desc limit 50");
                        while($rs=$DB->fetch($a)){
                            if ($rs['status'] == 1) {
                                $zt = '<span class="badge bg-success">已支付</span>';
                            }else{
                                $zt = '<span class="badge bg-danger">未支付</span>';
                            }
                            echo "<tr><td>".$rs['oid']."</td>
                              <td>".$rs['out_trade_no']."</td>
                              <td>".$rs['uid']."</td>
                              <td>".$rs['type']."</td>
                              <td>".$rs['name']."</td>
                              <td>".$rs['money']."</td>
                              <td>".$rs['addtime']."</td>
                              <td>".$rs['endtime']."</td>
                              <td>".$zt."</td></tr>"; 
                        }
                        ?>
                      </tbody>
                      <!--end::Table body-->
                    </table>
                    <!--end::Table-->
                  </div>
                </div>
                <?php } ?>
                <!--end::Card body-->
              </div>
              <!--end::Card-->
            </div>
            <!--end::Container-->
          </div>
          <!--end::Post-->
        </div>
        <!--页面主内容 - 结束-->
        <!--页面底部 - 开始-->
        <?php include('./footer.php'); ?>
        <!--页面底部 - 结束-->
      </div>
      <!--end::Wrapper-->
    </div>
    <!--end::Page-->
  </div>
  <!--end::Root-->
  <!-- 底部 - 开始 -->
  <?php require_once('./foot.php'); ?>
  <!-- 底部 - 结束 -->
  <!-- 本页面需要 - 开始 -->

  <!-- 本页面需要 - 结束 -->
</body>
<!--end::Body-->
</html>