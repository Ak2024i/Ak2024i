<div class="d-flex flex-stack flex-wrap pt-10">
  <div class="fs-6 fw-bold text-gray-700">展示 1 - 20 条数据</div>
  <!--begin::Pages-->
  <ul class="pagination">
    <li class="page-item previous" @click="row.current_page>1?get(row.current_page-1):''" :class="{'disabled':row.current_page==1}">
      <a href="javascript:;" class="page-link">
        <i class="previous"></i>
      </a>
    </li>
    <li class="page-item" @click="row.current_page>1?get(row.current_page-3):''" v-if="row.current_page-3>=1">
      <a href="javascript:;" class="page-link">{{ row.current_page-3 }}</a>
    </li>
    <li class="page-item" @click="get(row.current_page-2)" v-if="row.current_page-2>=1">
      <a href="javascript:;" class="page-link">{{ row.current_page-2 }}</a>
    </li>
    <li class="page-item" @click="get(row.current_page-1)" v-if="row.current_page-1>=1">
      <a href="javascript:;" class="page-link">{{ row.current_page-1 }}</a>
    </li>
    <li class="page-item" :class="{'active':row.current_page==row.current_page}" @click="get(row.current_page)" v-if="row.current_page">
      <a href="javascript:;" class="page-link">{{ row.current_page }}</a>
    </li>
    <li class="page-item" @click="get(row.current_page+1)" v-if="row.current_page+1<=row.last_page">
      <a href="javascript:;" class="page-link">{{ row.current_page+1 }}</a>
    </li>
    <li class="page-item" @click="get(row.current_page+2)" v-if="row.current_page+2<=row.last_page">
      <a href="javascript:;" class="page-link">{{ row.current_page+2 }}</a>
    </li>
    <li class="page-item" @click="get(row.current_page+3)" v-if="row.current_page+3<=row.last_page">
      <a href="javascript:;" class="page-link">{{ row.current_page+3 }}</a>
    </li>
    <li class="page-item next" @click="row.last_page>row.current_page?get(row.current_page+1):''" :class="{'disabled':row.current_page==row.last_page}">
      <a href="javascript:;" class="page-link">
        <i class="next"></i>
      </a>
    </li>
  </ul>
  <!--end::Pages-->
</div>