<!DOCTYPE html>
<html lang="zh">
<?php $pagename="提交工单"; ?>
<!-- 头部 - 开始 -->
<?php
require_once('./head.php');
?>
<!-- 头部 - 结束 -->

<!--begin::Body-->
<body id="kt_body"
  class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled aside-fixed aside-default-enabled">

  <!--begin::Root-->
  <div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="page d-flex flex-row flex-column-fluid">
      <!--侧边栏 - 开始-->
      <?php include('./aside.php'); ?>
      <!--侧边栏 - 结束-->
      <!--begin::Wrapper-->
      <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
        <!--页面头部 - 开始-->
        <?php include('./header.php'); ?>
        <!--页面头部 - 结束-->
        <!--页面主内容 - 开始-->
        <div class="content fs-6 d-flex flex-column flex-column-fluid" id="gdlist">
          <!--begin::Toolbar-->
          <div class="toolbar" id="kt_toolbar">
            <div class="container-fluid d-flex flex-stack flex-wrap flex-sm-nowrap">
              <!--begin::Info-->
              <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                <!--begin::Title-->
                <h1 class="text-dark fw-bolder my-1 fs-2"><?php echo $pagename ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb fw-bold fs-base my-1">
                  <li class="breadcrumb-item text-muted">
                    <a href="./index" class="text-muted text-hover-primary">首页</a>
                  </li>
                  <li class="breadcrumb-item text-muted">用户中心</li>
                  <li class="breadcrumb-item text-dark"><?php echo $pagename ?></li>
                </ul>
                <!--end::Breadcrumb-->
              </div>
              <!--end::Info-->
              <!--begin::Actions-->
              <div class="d-flex align-items-center flex-nowrap text-nowrap py-1">
                <a href="#" class="btn bg-body btn-color-gray-700 btn-active-primary me-4" data-bs-toggle="modal" data-bs-target="#modal_userknow">用户须知</a>
                <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_add">添加工单</a>
              </div>
              <!--end::Actions-->
            </div>
          </div>
          <!--end::Toolbar-->
          <!--begin::Post-->
          <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div class="container-xxl">
              <!--begin::Tab Content-->
              <div v-if="order == null" class="card-body pt-0">
                <div class="text-center px-5">
                  <img src="static/picture/20.png" alt="" class="mw-100 mh-325px">
                  <h1 class="fw-bold mt-5" style="color: #A3A3C7">暂无数据</h1>
                </div>
              </div>
              <div v-else class="tab-content">
                <!--begin::Row-->
                <div class="row g-6 g-xl-9">
                  <!--begin::Col-->
                  <div class="col-md-6 col-xxl-4" v-for="res in order">
                    <!--begin::Card-->
                    <div class="card">
                      <!--begin::Card body-->
                      <div class="card-body d-flex flex-center flex-column pt-12 p-9">
                        <!--begin::Avatar-->
                        <div class="symbol symbol-65px symbol-circle mb-7">
                          <img :src="'http://q2.qlogo.cn/headimg_dl?dst_uin=' + res.user + '&spec=100'" alt="image">
                          <el-tooltip effect="dark" :content="res.state" placement="right">
                            <div v-if="res.state=='待回复'" class="bg-primary position-absolute h-15px w-15px rounded-circle translate-middle start-100 top-100 ms-n3 mt-n3"></div>
                            <div v-else-if="res.state=='已关闭' || res.state=='已回复'" class="bg-success position-absolute h-15px w-15px rounded-circle translate-middle start-100 top-100 ms-n3 mt-n3"></div>
                            <div v-else-if="res.state=='已驳回'" class="bg-danger position-absolute h-15px w-15px rounded-circle translate-middle start-100 top-100 ms-n3 mt-n3"></div>
                            <div v-else class="bg-warning position-absolute h-15px w-15px rounded-circle translate-middle start-100 top-100 ms-n3 mt-n3"></div>
                          </el-tooltip>
                        </div>
                        <!--end::Avatar-->
                        <!--begin::Name-->
                        <a href="JavaScript:;" data-bs-toggle="modal" data-bs-target="#modal_check" @click="check(res)" class="fs-3 text-gray-800 text-hover-primary fw-boldest mb-1">{{res.region}}</a>
                        <!--end::Name-->
                        <!--begin::Position-->
                        <div class="fs-5 fw-bold text-gray-400 mb-6">订单编号：{{res.oid}}</div>
                        <!--end::Position-->
                        <!-- 操作按钮 - 开始 -->
                        <div class="d-flex flex-wrap flex-center">
                          <?php if($userrow['uid']==1){?>
                          <el-dropdown trigger="click" @command="handleMenu" placement="bottom">
                            <button type="button" class="btn btn-primary me-3">
                                处理工单
                                <span class="svg-icon svg-icon-5 rotate-180 ms-3 me-0">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                  <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="black"></path>
                                </svg>
                                </span>
                            </button>
                            <template #dropdown>
                              <el-dropdown-menu>
                                <el-dropdown-item :command="{res,type:'reply'}">回复工单</el-dropdown-item>
                                <el-dropdown-item :command="{res,type:'reblack'}">驳回工单</el-dropdown-item>
                                <el-dropdown-item :command="{res,type:'close'}">关闭工单</el-dropdown-item>
                                <el-dropdown-item :command="{res,type:'untreated'}">暂不处理</el-dropdown-item>
                                <el-dropdown-item :command="{res,type:'delete'}">删除工单</el-dropdown-item>
                              </el-dropdown-menu>
                            </template>
                          </el-dropdown>
                          <?php } else { ?>
                          <a href="#" v-show="res.state=='已关闭'?false:true" class="btn btn-primary me-3" data-bs-toggle="modal" data-bs-target="#modal_userreply" @click="userReplyInit(res)">回复邮件</a>
                          <?php } ?>
                          <a href="#" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#modal_check" @click="check(res)">查看详情</a>
                        </div>
                        <!-- 操作按钮 - 结束 -->
                      </div>
                      <!--end::Card body-->
                    </div>
                    <!--end::Card-->
                  </div>
                  <!--end::Col-->
                </div>
                <!--end::Row-->
                <!--begin::Pagination-->
                <?php include('./pagination.php') ?>
                <!--end::Pagination-->
              </div>
              <!--end::Tab Content-->
            </div>
            <!--end::Container-->
          </div>
          <!--end::Post-->
          <!--添加弹窗 - 开始-->
          <div class="modal fade" id="modal_add" tabindex="-1" aria-hidden="true">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-650px">
              <!--begin::Modal content-->
              <div class="modal-content">
                <!--begin::Modal header-->
                <div class="modal-header">
                  <!--begin::Modal title-->
                  <h3 class="fw-boldest text-dark fs-1 mb-0">添加工单</h3>
                  <!--end::Modal title-->
                  <!--begin::Close-->
                  <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-2x">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                      </svg>
                    </span>
                    <!--end::Svg Icon-->
                  </div>
                  <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Form-->
                <form class="form" @submit.prevent="">
                  <!--begin::Modal body-->
                  <div class="modal-body py-10 px-lg-17">
                    <!--begin::Scroll-->
                    <div class="scroll-y me-n7 pe-7" data-kt-scroll="true" data-kt-scroll-max-height="auto" data-kt-scroll-offset="300px">
                      <!--begin::Notice-->
                      <div class="notice d-flex bg-light-warning rounded border-warning border border-dashed mb-10 p-6">
                        <!--begin::Icon-->
                        <!--begin::Svg Icon | path: icons/duotune/general/gen044.svg-->
                        <span class="svg-icon svg-icon-2tx svg-icon-warning me-4">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                            <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
                            <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                        <!--end::Icon-->
                        <!--begin::Wrapper-->
                        <div class="d-flex flex-stack flex-grow-1">
                          <!--begin::Content-->
                          <div class="fw-bold">
                            <h4 class="text-gray-900 fw-bolder">非订单问题请按如下填写订单编号！</h4>
                            <div class="fs-6 text-gray-700">充值问题：001；代理问题：002；提出意见：003</div>
                          </div>
                          <!--end::Content-->
                        </div>
                        <!--end::Wrapper-->
                      </div>
                      <!--end::Notice-->
                      <!--begin::Input group-->
                      <div class="row g-9 mb-8" data-select2-id="select2-data-179-tdus">
                        <!--begin::Col-->
                        <div class="col-md-6 fv-row">
                         <!--begin::Label-->
                          <label class="required fs-5 fw-bold mb-2">工单类型</label>
                          <!--end::Label-->
                          <!--begin::Select-->
                          <select id="addFormRegion" data-control="select2" data-hide-search="true" data-placeholder="请选择工单类型..." class="form-select form-select-solid">
                            <option></option>
                            <option value="订单问题">订单问题</option>
                            <option value="充值问题">充值问题</option>
                            <option value="代理问题">代理问题</option>
                            <option value="提出意见">提出意见</option>
                          </select>
                          <!--end::Select-->
                        </div>
                        <!--end::Col-->
                        <!--begin::Col-->
                        <div class="col-md-6 fv-row">
                          <!--begin::Label-->
                          <label class="required fs-5 fw-bold mb-2">订单编号</label>
                          <!--end::Label-->
                          <!--begin::Input-->
                          <input type="text" v-model="addForm.oid" class="form-control form-control-solid" placeholder="请输入订单编号">
                          <!--end::Input-->
                        </div>
                        <!--end::Col-->
                      </div>
                      <!--end::Input group-->
                      <!--begin::Input group-->
                      <div class="mb-5 fv-row">
                        <!--begin::Label-->
                        <label class="required fs-5 fw-bold mb-2">工单内容</label>
                        <!--end::Label-->
                        <!--begin::Input-->
                        <textarea v-model="addForm.content" class="form-control form-control-solid" rows="3" placeholder="请描述您当前遇到的问题"></textarea>
                        <!--end::Input-->
                      </div>
                      <!--end::Input group-->
                    </div>
                    <!--end::Scroll-->
                  </div>
                  <!--end::Modal body-->
                  <!--begin::Modal footer-->
                  <div class="modal-footer flex-center">
                    <!--begin::Button-->
                    <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">取消</button>
                    <!--end::Button-->
                    <!--begin::Button-->
                    <button type="button" id="addSubmitBtn" @click="handleAdd()" class="btn btn-primary">
                      <span class="indicator-label">确认提交</span>
                      <span class="indicator-progress">Please wait... 
                      <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                    </button>
                    <!--end::Button-->
                  </div>
                  <!--end::Modal footer-->
                </form>
                <!--end::Form-->
              </div>
              <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
          </div>
          <!--添加弹窗 - 结束-->
          <!--用户回复弹窗 - 开始-->
          <div class="modal fade" id="modal_userreply" tabindex="-1" aria-hidden="true">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-650px">
              <!--begin::Modal content-->
              <div class="modal-content">
                <!--begin::Modal header-->
                <div class="modal-header">
                  <!--begin::Modal title-->
                  <h3 class="fw-boldest text-dark fs-1 mb-0">回复工单</h3>
                  <!--end::Modal title-->
                  <!--begin::Close-->
                  <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-2x">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                      </svg>
                    </span>
                    <!--end::Svg Icon-->
                  </div>
                  <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Form-->
                <form class="form" @submit.prevent="">
                  <!--begin::Modal body-->
                  <div class="modal-body py-10 px-lg-17">
                    <!--begin::Scroll-->
                    <div class="scroll-y me-n7 pe-7" data-kt-scroll="true" data-kt-scroll-max-height="auto" data-kt-scroll-offset="300px">
                      <!--begin::Notice-->
                      <div class="notice d-flex bg-light-warning rounded border-warning border border-dashed mb-10 p-6">
                        <!--begin::Icon-->
                        <!--begin::Svg Icon | path: icons/duotune/general/gen044.svg-->
                        <span class="svg-icon svg-icon-2tx svg-icon-warning me-4">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                            <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
                            <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                        <!--end::Icon-->
                        <!--begin::Wrapper-->
                        <div class="d-flex flex-stack flex-grow-1">
                          <!--begin::Content-->
                          <div class="fw-bold">
                            <h4 class="text-gray-900 fw-bolder">回复内容提示！</h4>
                            <div class="fs-6 text-gray-700">请勿删除之前的内容，接着后面写新内容即可</div>
                          </div>
                          <!--end::Content-->
                        </div>
                        <!--end::Wrapper-->
                      </div>
                      <!--end::Notice-->
                      <!--begin::Input group-->
                      <div class="row g-9 mb-8" data-select2-id="select2-data-179-tdus">
                        <!--begin::Col-->
                        <div class="col-md-6 fv-row">
                         <!--begin::Label-->
                          <label class="required fs-5 fw-bold mb-2">工单类型</label>
                          <!--end::Label-->
                          <!--begin::Select-->
                          <select v-model="userForm.region" data-hide-search="true" data-placeholder="请选择工单类型..." class="form-select form-select-solid" disabled>
                            <option></option>
                            <option value="订单问题" selected>订单问题</option>
                            <option value="充值问题">充值问题</option>
                            <option value="代理问题">代理问题</option>
                            <option value="提出意见">提出意见</option>
                          </select>
                          <!--end::Select-->
                        </div>
                        <!--end::Col-->
                        <!--begin::Col-->
                        <div class="col-md-6 fv-row">
                          <!--begin::Label-->
                          <label class="required fs-5 fw-bold mb-2">订单编号</label>
                          <!--end::Label-->
                          <!--begin::Input-->
                          <input type="text" class="form-control form-control-solid" placeholder="请输入订单编号" :value="userForm.oid" disabled>
                          <!--end::Input-->
                        </div>
                        <!--end::Col-->
                      </div>
                      <!--end::Input group-->
                      <!--begin::Input group-->
                      <div class="mb-5 fv-row">
                        <!--begin::Label-->
                        <label class="required fs-5 fw-bold mb-2">工单内容</label>
                        <!--end::Label-->
                        <!--begin::Input-->
                        <textarea v-model="userForm.content" class="form-control form-control-solid" rows="3" placeholder="请描述您当前遇到的问题"></textarea>
                        <!--end::Input-->
                      </div>
                      <!--end::Input group-->
                    </div>
                    <!--end::Scroll-->
                  </div>
                  <!--end::Modal body-->
                  <!--begin::Modal footer-->
                  <div class="modal-footer flex-center">
                    <!--begin::Button-->
                    <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">取消</button>
                    <!--end::Button-->
                    <!--begin::Button-->
                    <button type="button" id="userReplySubmitBtn" @click="handleToAnswer()" class="btn btn-primary">
                      <span class="indicator-label">确认提交</span>
                      <span class="indicator-progress">Please wait... 
                      <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                    </button>
                    <!--end::Button-->
                  </div>
                  <!--end::Modal footer-->
                </form>
                <!--end::Form-->
              </div>
              <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
          </div>
          <!--用户回复弹窗 - 结束-->
          <!--管理员回复弹窗 - 开始-->
          <div class="modal fade" id="modal_adminreply" tabindex="-1" aria-hidden="true">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-650px">
              <!--begin::Modal content-->
              <div class="modal-content">
                <!--begin::Modal header-->
                <div class="modal-header">
                  <!--begin::Modal title-->
                  <h3 class="fw-boldest text-dark fs-1 mb-0">回复工单</h3>
                  <!--end::Modal title-->
                  <!--begin::Close-->
                  <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-2x">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                      </svg>
                    </span>
                    <!--end::Svg Icon-->
                  </div>
                  <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Form-->
                <form class="form" @submit.prevent="">
                  <!--begin::Modal body-->
                  <div class="modal-body py-10 px-lg-17">
                    <!--begin::Scroll-->
                    <div class="scroll-y me-n7 pe-7" data-kt-scroll="true" data-kt-scroll-max-height="auto" data-kt-scroll-offset="300px">
                      <!--begin::Notice-->
                      <div class="notice d-flex bg-light-warning rounded border-warning border border-dashed mb-10 p-6">
                        <!--begin::Icon-->
                        <!--begin::Svg Icon | path: icons/duotune/general/gen044.svg-->
                        <span class="svg-icon svg-icon-2tx svg-icon-warning me-4">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                            <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
                            <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                        <!--end::Icon-->
                        <!--begin::Wrapper-->
                        <div class="d-flex flex-stack flex-grow-1">
                          <!--begin::Content-->
                          <div class="fw-bold">
                            <h4 class="text-gray-900 fw-bolder">回复内容提示！</h4>
                            <div class="fs-6 text-gray-700">请勿删除之前的内容，接着后面写新内容即可</div>
                          </div>
                          <!--end::Content-->
                        </div>
                        <!--end::Wrapper-->
                      </div>
                      <!--end::Notice-->
                      <!--begin::Input group-->
                      <div class="row g-9 mb-8" data-select2-id="select2-data-179-tdus">
                        <!--begin::Col-->
                        <div class="col-md-6 fv-row">
                         <!--begin::Label-->
                          <label class="required fs-5 fw-bold mb-2">工单类型</label>
                          <!--end::Label-->
                          <!--begin::Select-->
                          <select v-modal="adminControlInfo.region" data-hide-search="true" data-placeholder="请选择工单类型..." class="form-select form-select-solid" disabled>
                            <option value="订单问题">订单问题</option>
                            <option value="充值问题">充值问题</option>
                            <option value="代理问题">代理问题</option>
                            <option value="提出意见">提出意见</option>
                          </select>
                          <!--end::Select-->
                        </div>
                        <!--end::Col-->
                        <!--begin::Col-->
                        <div class="col-md-6 fv-row">
                          <!--begin::Label-->
                          <label class="required fs-5 fw-bold mb-2">订单编号</label>
                          <!--end::Label-->
                          <!--begin::Input-->
                          <input type="text" class="form-control form-control-solid" placeholder="请输入订单编号" :value="adminControlInfo.oid" disabled>
                          <!--end::Input-->
                        </div>
                        <!--end::Col-->
                      </div>
                      <!--end::Input group-->
                      <!--begin::Input group-->
                      <div class="mb-5 fv-row">
                        <!--begin::Label-->
                        <label class="required fs-5 fw-bold mb-2">回复内容</label>
                        <!--end::Label-->
                        <!--begin::Input-->
                        <textarea v-model="adminControlInfo.answer" class="form-control form-control-solid" rows="3" placeholder="请输入回复内容"></textarea>
                        <!--end::Input-->
                      </div>
                      <!--end::Input group-->
                    </div>
                    <!--end::Scroll-->
                  </div>
                  <!--end::Modal body-->
                  <!--begin::Modal footer-->
                  <div class="modal-footer flex-center">
                    <!--begin::Button-->
                    <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">取消</button>
                    <!--end::Button-->
                    <!--begin::Button-->
                    <button type="button" id="adminReplySubmitBtn" @click="handldeReply()" class="btn btn-primary">
                      <span class="indicator-label">确认提交</span>
                      <span class="indicator-progress">Please wait... 
                      <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                    </button>
                    <!--end::Button-->
                  </div>
                  <!--end::Modal footer-->
                </form>
                <!--end::Form-->
              </div>
              <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
          </div>
          <!--管理员回复弹窗 - 结束-->
          <!--驳回弹窗 - 开始-->
          <div class="modal fade" id="modal_reblack" tabindex="-1" aria-hidden="true">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-650px">
              <!--begin::Modal content-->
              <div class="modal-content">
                <!--begin::Modal header-->
                <div class="modal-header">
                  <!--begin::Modal title-->
                  <h3 class="fw-boldest text-dark fs-1 mb-0">驳回工单</h3>
                  <!--end::Modal title-->
                  <!--begin::Close-->
                  <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-2x">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                      </svg>
                    </span>
                    <!--end::Svg Icon-->
                  </div>
                  <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Form-->
                <form class="form" @submit.prevent="">
                  <!--begin::Modal body-->
                  <div class="modal-body py-10 px-lg-17">
                    <!--begin::Scroll-->
                    <div class="scroll-y me-n7 pe-7" data-kt-scroll="true" data-kt-scroll-max-height="auto" data-kt-scroll-offset="300px">
                      <!--begin::Notice-->
                      <div class="notice d-flex bg-light-warning rounded border-warning border border-dashed mb-10 p-6">
                        <!--begin::Icon-->
                        <!--begin::Svg Icon | path: icons/duotune/general/gen044.svg-->
                        <span class="svg-icon svg-icon-2tx svg-icon-warning me-4">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                            <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
                            <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                        <!--end::Icon-->
                        <!--begin::Wrapper-->
                        <div class="d-flex flex-stack flex-grow-1">
                          <!--begin::Content-->
                          <div class="fw-bold">
                            <h4 class="text-gray-900 fw-bolder">回复内容提示！</h4>
                            <div class="fs-6 text-gray-700">请勿删除之前的内容，接着后面写新内容即可</div>
                          </div>
                          <!--end::Content-->
                        </div>
                        <!--end::Wrapper-->
                      </div>
                      <!--end::Notice-->
                      <!--begin::Input group-->
                      <div class="row g-9 mb-8" data-select2-id="select2-data-179-tdus">
                        <!--begin::Col-->
                        <div class="col-md-6 fv-row">
                         <!--begin::Label-->
                          <label class="required fs-5 fw-bold mb-2">工单类型</label>
                          <!--end::Label-->
                          <!--begin::Select-->
                          <select v-modal="adminControlInfo.region" data-control="select2" data-hide-search="true" data-placeholder="请选择工单类型..." class="form-select form-select-solid" disabled>
                            <option value="订单问题">订单问题</option>
                            <option value="充值问题">充值问题</option>
                            <option value="代理问题">代理问题</option>
                            <option value="提出意见">提出意见</option>
                          </select>
                          <!--end::Select-->
                        </div>
                        <!--end::Col-->
                        <!--begin::Col-->
                        <div class="col-md-6 fv-row">
                          <!--begin::Label-->
                          <label class="required fs-5 fw-bold mb-2">订单编号</label>
                          <!--end::Label-->
                          <!--begin::Input-->
                          <input type="text" class="form-control form-control-solid" placeholder="请输入订单编号" name="name" :value="adminControlInfo.oid" disabled>
                          <!--end::Input-->
                        </div>
                        <!--end::Col-->
                      </div>
                      <!--end::Input group-->
                      <!--begin::Input group-->
                      <div class="mb-5 fv-row">
                        <!--begin::Label-->
                        <label class="required fs-5 fw-bold mb-2">驳回内容</label>
                        <!--end::Label-->
                        <!--begin::Input-->
                        <textarea v-model="adminControlInfo.answer" class="form-control form-control-solid" rows="3" name="cookie" placeholder="请输入驳回内容"></textarea>
                        <!--end::Input-->
                      </div>
                      <!--end::Input group-->
                    </div>
                    <!--end::Scroll-->
                  </div>
                  <!--end::Modal body-->
                  <!--begin::Modal footer-->
                  <div class="modal-footer flex-center">
                    <!--begin::Button-->
                    <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">取消</button>
                    <!--end::Button-->
                    <!--begin::Button-->
                    <button type="button" id="adminReBlackSubmitBtn" @click="handldeReBlack()" class="btn btn-primary">
                      <span class="indicator-label">确认提交</span>
                      <span class="indicator-progress">Please wait... 
                      <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                    </button>
                    <!--end::Button-->
                  </div>
                  <!--end::Modal footer-->
                </form>
                <!--end::Form-->
              </div>
              <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
          </div>
          <!--驳回弹窗 - 结束-->
          <!--工单详情 - 开始-->
          <div class="modal fade" id="modal_check" tabindex="-1" aria-hidden="true">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-650px">
              <!--begin::Modal content-->
              <div class="modal-content">
                <!--begin::Modal header-->
                <div class="modal-header">
                  <!--begin::Modal title-->
                  <h3 class="fw-boldest text-dark fs-1 mb-0">工单详情</h3>
                  <!--end::Modal title-->
                  <!--begin::Close-->
                  <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-2x">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                      </svg>
                    </span>
                    <!--end::Svg Icon-->
                  </div>
                  <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Form-->
                <form class="form">
                  <!--begin::Modal body-->
                  <div class="modal-body py-10 px-lg-17">
                    <!--begin::Scroll-->
                    <div class="scroll-y me-n7 pe-7" data-kt-scroll="true" data-kt-scroll-max-height="auto" data-kt-scroll-offset="300px">
                      <!--begin::Input group-->
                      <div class="row g-9 mb-8" data-select2-id="select2-data-179-tdus">
                        <!--begin::Col-->
                        <div class="col-md-6 fv-row">
                         <!--begin::Label-->
                          <label class="required fs-5 fw-bold mb-2">工单类型</label>
                          <!--end::Label-->
                          <!--begin::Select-->
                          <select v-model="publicForm.region" data-hide-search="true" data-placeholder="请选择工单类型..." class="form-select form-select-solid" disabled>
                            <option value="订单问题">订单问题</option>
                            <option value="充值问题">充值问题</option>
                            <option value="代理问题">代理问题</option>
                            <option value="提出意见">提出意见</option>
                          </select>
                          <!--end::Select-->
                        </div>
                        <!--end::Col-->
                        <!--begin::Col-->
                        <div class="col-md-6 fv-row">
                          <!--begin::Label-->
                          <label class="required fs-5 fw-bold mb-2">订单编号</label>
                          <!--end::Label-->
                          <!--begin::Input-->
                          <input type="text" class="form-control form-control-solid" placeholder="请输入订单编号" :value="publicForm.oid" disabled>
                          <!--end::Input-->
                        </div>
                        <!--end::Col-->
                      </div>
                      <!--end::Input group-->
                      <!--begin::Input group-->
                      <div class="mb-5 fv-row">
                        <!--begin::Label-->
                        <label class="required fs-5 fw-bold mb-2">工单内容</label>
                        <!--end::Label-->
                        <!--begin::Input-->
                        <textarea v-model="publicForm.content" class="form-control form-control-solid" rows="3" placeholder="请描述您当前遇到的问题"></textarea>
                        <!--end::Input-->
                      </div>
                      <!--end::Input group-->
                      <!--begin::Input group-->
                      <div class="mb-5 fv-row">
                        <!--begin::Label-->
                        <label class="required fs-5 fw-bold mb-2">回复内容</label>
                        <!--end::Label-->
                        <!--begin::Input-->
                        <textarea v-model="publicForm.answer" class="form-control form-control-solid" rows="3" placeholder="请输入回复内容"></textarea>
                        <!--end::Input-->
                      </div>
                      <!--end::Input group-->
                    </div>
                    <!--end::Scroll-->
                  </div>
                  <!--end::Modal body-->
                  <!--begin::Modal footer-->
                  <div class="modal-footer flex-center">
                    <!--begin::Button-->
                    <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">关闭</button>
                    <!--end::Button-->
                  </div>
                  <!--end::Modal footer-->
                </form>
                <!--end::Form-->
              </div>
              <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
          </div>
          <!--工单详情 - 结束-->
          <!--用户须知 - 开始-->
          <div class="modal fade" id="modal_userknow" tabindex="-1" aria-hidden="true">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-650px">
              <!--begin::Modal content-->
              <div class="modal-content">
                <!--begin::Modal header-->
                <div class="modal-header">
                  <!--begin::Modal title-->
                  <h3 class="fw-boldest text-dark fs-1 mb-0">用户须知</h3>
                  <!--end::Modal title-->
                  <!--begin::Close-->
                  <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-2x">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                      </svg>
                    </span>
                    <!--end::Svg Icon-->
                  </div>
                  <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Form-->
                <form class="form">
                  <!--begin::Modal body-->
                  <div class="modal-body py-10 px-lg-17">
                    <!--begin::Scroll-->
                    <div class="scroll-y me-n7 pe-7" data-kt-scroll="true" data-kt-scroll-max-height="auto" data-kt-scroll-offset="300px">
                      <p>1.为了节省资源，一份工单可进行多次回复。为了方便查看过往的聊天记录，多次回复时请勿删除上次的工单内容，接着在后面写新内容即可！！！</p>
                      <p>2.当工单完成后，管理员将会关闭此工单，已关闭的工单用户将不能对其再进行任何操作，只能查看工单详情！！！</p>
                    </div>
                    <!--end::Scroll-->
                  </div>
                  <!--end::Modal body-->
                  <!--begin::Modal footer-->
                  <div class="modal-footer flex-center">
                    <!--begin::Button-->
                    <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">关闭</button>
                    <!--end::Button-->
                  </div>
                  <!--end::Modal footer-->
                </form>
                <!--end::Form-->
              </div>
              <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
          </div>
          <!--用户须知 - 结束-->
        </div>
        <!--页面主内容 - 结束-->
        <!--页面底部 - 开始-->
        <?php include('./footer.php'); ?>
        <!--页面底部 - 结束-->
      </div>
      <!--end::Wrapper-->
    </div>
    <!--end::Page-->
  </div>
  <!--end::Root-->
  <!-- 底部 - 开始 -->
  <?php require_once('./foot.php'); ?>
  <!-- 底部 - 结束 -->
  <!-- 本页面需要 - 开始 -->
  <script src="static/js/element.js"></script>
  <script src="static/main/pages/workorder.js"></script>
  <!-- 本页面需要 - 结束 -->
</body>
<!--end::Body-->
</html>