<!DOCTYPE html>
<html lang="zh">
<?php $pagename="任务列表" ?>
<!-- 头部 - 开始 -->
<?php require_once('./head.php'); ?>
<!-- 头部 - 结束 -->

<!--begin::Body-->

<body id="kt_body"
  class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled aside-fixed aside-default-enabled">

  <!--begin::Root-->
  <div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="page d-flex flex-row flex-column-fluid">
      <!--侧边栏 - 开始-->
      <?php include('./aside.php'); ?>
      <!--侧边栏 - 结束-->
      <!--begin::Wrapper-->
      <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
        <!--页面头部 - 开始-->
        <?php include('./header.php'); ?>
        <!--页面头部 - 结束-->
        <!--页面主内容 - 开始-->
        <div class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
          <!--begin::Toolbar-->
          <div class="toolbar" id="kt_toolbar">
            <div class="container-fluid d-flex flex-stack flex-wrap flex-sm-nowrap">
              <!--begin::Info-->
              <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                <!--begin::Title-->
                <h1 class="text-dark fw-bolder my-1 fs-2"><?php echo $pagename ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb fw-bold fs-base my-1">
                  <li class="breadcrumb-item text-muted">
                    <a href="./index" class="text-muted text-hover-primary">首页</a>
                  </li>
                  <li class="breadcrumb-item text-muted">用户中心</li>
                  <li class="breadcrumb-item text-dark"><?php echo $pagename ?></li>
                </ul>
                <!--end::Breadcrumb-->
              </div>
              <!--end::Info-->
              <!--begin::Actions-->
              <div class="d-flex align-items-center flex-nowrap text-nowrap py-1">
                <a href="JavaScript:;" class="btn bg-body btn-color-gray-700 btn-active-primary me-4" data-bs-toggle="modal" data-bs-target="#modal_usernotice">站点公告</a>
                <a href="JavaScript:;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_tcgonggao">重要通知</a>
              </div>
              <!--end::Actions-->
            </div>
          </div>
          <!--end::Toolbar-->
          <!--begin::Post-->
          <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div id="list" class="container-xxl">
              <!--begin::Form-->
              <form @submit.prevent="">
                <!--begin::Card-->
                <div class="card mb-7">
                  <!--begin::Card body-->
                  <div class="card-body">
                    <!--begin::Compact form-->
                    <div class="d-flex align-items-center">
                      <!--begin::Input group-->
                      <div class="position-relative w-md-200px me-md-2">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen021.svg-->
                        <span class="svg-icon svg-icon-3 svg-icon-gray-500 position-absolute top-50 translate-middle ms-6">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="black"></rect>
                            <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="black"></path>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                        <input type="text" class="form-control form-control-solid ps-10" v-model="cx.oid" placeholder="请输入订单ID">
                      </div>
                      <!--end::Input group-->
                      <?php if($userrow['uid']==1){ ?>
                      <!--begin::Input group-->
                      <div class="position-relative w-md-200px me-md-2">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen021.svg-->
                        <span class="svg-icon svg-icon-3 svg-icon-gray-500 position-absolute top-50 translate-middle ms-6">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="black"></rect>
                            <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="black"></path>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                        <input type="text" class="form-control form-control-solid ps-10" v-model="cx.uid" placeholder="请输入用户UID">
                      </div>
                      <!--end::Input group-->
                      <?php } ?>
                      <!--begin::Input group-->
                      <div class="position-relative w-md-300px me-md-2">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen021.svg-->
                        <span class="svg-icon svg-icon-3 svg-icon-gray-500 position-absolute top-50 translate-middle ms-6">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="black"></rect>
                            <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="black"></path>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                        <input type="text" class="form-control form-control-solid ps-10" v-model="cx.qq" placeholder="请输入学号或手机号">
                      </div>
                      <!--end::Input group-->
                      <!--begin:Action-->
                      <div class="d-flex align-items-center">
                        <button type="submit" @click="get(1,1)" class="btn btn-primary me-5">点击查询</button>
                        <a id="kt_horizontal_search_advanced_link" class="btn btn-link" data-bs-toggle="collapse" href="#kt_advanced_search_form">高级搜索</a>
                      </div>
                      <!--end:Action-->
                    </div>
                    <!--end::Compact form-->
                    <!--begin::Advance form-->
                    <div class="collapse" id="kt_advanced_search_form">
                      <!--begin::Separator-->
                      <div class="separator separator-dashed mt-9 mb-6"></div>
                      <!--end::Separator-->
                      <!--begin::Row-->
                      <div class="row g-8 d-flex align-items-end">
                        <!--begin::Col-->
                        <div class="col-xxl-4">
                          <!--begin::Row-->
                          <div class="row g-8">
                            <!--begin::Col-->
                            <div class="col-lg-6">
                              <label class="fs-6 form-label fw-boldest text-dark">课程名称</label>
                              <!--begin::Select-->
                              <select v-model="cx.cid" class="form-select form-select-solid" data-placeholder="请选择课程名称" data-hide-search="true">
                                <?php
					                	     	$a=$DB->query("select * from qingka_wangke_class where status=1 ");
															    while($row=$DB->fetch($a)){
							                       echo '<option value="'.$row['cid'].'">'.$row['name'].'</option>';
															    }
					                      ?>   
                              </select>
                              <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-6">
                              <label class="fs-6 form-label fw-boldest text-dark">任务状态</label>
                              <!--begin::Select-->
                              <select v-model="cx.status_text" class="form-select form-select-solid" data-placeholder="请选择任务状态" data-hide-search="true">
                                <option value="待处理">待处理</option>
                                <option value="进行中">进行中</option>
                                <option value="已完成">已完成</option>
                                <option value="补刷中">补刷中</option>
                                <option value="异常">异常中</option>
                                <option value="已取消">已取消</option>
                                <option value="已退款">已退款</option>
                              </select>
                              <!--end::Select-->
                            </div>
                            <!--end::Col-->
                          </div>
                          <!--end::Row-->
                        </div>
                        <!--end::Col-->
                        <!--begin::Col-->
                        <div class="col-xxl-4">
                          <!--begin::Row-->
                          <div class="row g-8">
                            <?php if($userrow['uid']==1){ ?>
                            <!--begin::Col-->
                            <div class="col-lg-6">
                              <label class="fs-6 form-label fw-boldest text-dark">处理状态</label>
                              <!--begin::Select-->
                              <select v-model="cx.dock" class="form-select form-select-solid" data-placeholder="请选择处理状态" data-hide-search="true">
                                <option value="0">待处理</option>
                                <option value="1">处理成功</option>
                                <option value="2">处理失败</option>
                                <option value="3">重复下单</option>
                                <option value="4">已取消</option>
                                <option value="99">我的</option>
                              </select>
                              <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php } ?>
                            <!--begin::Col-->
                            <?php if($userrow['uid']==1){ ?>
                            <div class="col-lg-6">
                            <?php } else {?>
                            <div class="col-lg-12">
                            <?php } ?>
                              <label class="fs-6 form-label fw-boldest text-dark">导出格式</label>
                              <!--begin::Select-->
                              <select v-model="dc2.gs" class="form-select form-select-solid" data-placeholder="请选择导出格式" data-hide-search="true">
                                <option value="1">学校+账号+密码+课程名字</option>
                                <option value="2">账号+密码+课程名字</option>
                                <option value="3">学校+账号+密码</option>
                                <option value="4">账号+密码</option>
                              </select>
                              <!--end::Select-->
                            </div>
                            <!--end::Col-->
                          </div>
                          <!--end::Row-->
                        </div>
                        <!--end::Col-->
                        <!--begin::Col-->
                        <div class="col-xxl-4">
                          <!--begin::Row-->
                          <div class="row g-8">
                            <!--begin::Col-->
                            <div class="col-lg-6">
                              <button type="submit" @click="daochu()" class="btn btn-success me-5">导出订单</button>
                            </div>
                            <!--end::Col-->
                          </div>
                          <!--end::Row-->
                        </div>
                        <!--end::Col-->
                      </div>
                      <!--end::Row-->
                    </div>
                    <!--end::Advance form-->
                  </div>
                  <!--end::Card body-->
                </div>
                <!--end::Card-->
              </form>
              <!--end::Form-->
              <!--begin::Card-->
              <div class="card">
                <!--begin::Card header-->
                <div class="card-header border-0 pt-6">
                  <!--begin::Card title-->
                  <div class="card-title flex-column">
                    <h2 class="fw-boldest mb-2">任务列表</h2>
                    <div class="fs-6 fw-bold text-gray-400">
                      <?php if($userrow['uid']==1){ ?>
                        勾选订单后才能修改任务状态或者处理状态
                      <?php } else { ?>
                        展示该用户的所有订单
                      <?php } ?>
                    </div>
                  </div>
                  <!--begin::Card title-->
                  <?php if($userrow['uid']==1){ ?>
                  <!--begin::Card toolbar-->
                  <div class="card-toolbar">
                    <!--begin::Toolbar-->
                    <div class="d-flex justify-content-end" data-kt-user-table-toolbar="base">
                      <!--任务状态 - 开始-->
                      <div>
                        <button type="button" class="btn btn-light-primary me-3" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr078.svg-->
                        <span class="svg-icon svg-icon-2">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M18.0002 22H6.00019C5.20019 22 4.8002 21.1 5.2002 20.4L12.0002 12L18.8002 20.4C19.3002 21.1 18.8002 22 18.0002 22Z" fill="currentColor"/>
                          <path opacity="0.3" d="M18.8002 3.6L12.0002 12L5.20019 3.6C4.70019 3 5.20018 2 6.00018 2H18.0002C18.8002 2 19.3002 2.9 18.8002 3.6Z" fill="currentColor"/>
                        </svg>
                        </span>
                        <!--end::Svg Icon-->任务状态</button>
                        <!-- 下拉菜单 - 开始 -->
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-125px py-4" data-kt-menu="true" style="">
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="status_text('待处理')">待处理</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="status_text('已完成')">已完成</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="status_text('进行中')">进行中</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="status_text('异常')">异常</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="status_text('已取消')">已取消</a>
                          </div>
                          <!--end::Menu item-->
                        </div>
                        <!-- 下拉菜单 - 结束 -->
                      </div>
                      <!--任务状态 - 结束-->
                      <!--处理状态 - 开始-->
                      <div>
                        <button type="button" class="btn btn-primary" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr075.svg-->
                        <span class="svg-icon svg-icon-2">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path opacity="0.3" d="M22.0318 8.59998C22.0318 10.4 21.4318 12.2 20.0318 13.5C18.4318 15.1 16.3318 15.7 14.2318 15.4C13.3318 15.3 12.3318 15.6 11.7318 16.3L6.93177 21.1C5.73177 22.3 3.83179 22.2 2.73179 21C1.63179 19.8 1.83177 18 2.93177 16.9L7.53178 12.3C8.23178 11.6 8.53177 10.7 8.43177 9.80005C8.13177 7.80005 8.73176 5.6 10.3318 4C11.7318 2.6 13.5318 2 15.2318 2C16.1318 2 16.6318 3.20005 15.9318 3.80005L13.0318 6.70007C12.5318 7.20007 12.4318 7.9 12.7318 8.5C13.3318 9.7 14.2318 10.6001 15.4318 11.2001C16.0318 11.5001 16.7318 11.3 17.2318 10.9L20.1318 8C20.8318 7.2 22.0318 7.59998 22.0318 8.59998Z" fill="currentColor"/>
                          <path d="M4.23179 19.7C3.83179 19.3 3.83179 18.7 4.23179 18.3L9.73179 12.8C10.1318 12.4 10.7318 12.4 11.1318 12.8C11.5318 13.2 11.5318 13.8 11.1318 14.2L5.63179 19.7C5.23179 20.1 4.53179 20.1 4.23179 19.7Z" fill="currentColor"/>
                        </svg>
                        </span>
                        <!--end::Svg Icon-->处理状态</button>
                        <!-- 下拉菜单 - 开始 -->
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-125px py-4" data-kt-menu="true" style="">
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="dock(0)">待处理</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="dock(1)">已完成</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="dock(2)">处理失败</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="dock(3)">重复下单</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="dock(4)">取消</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="dock(99)">我的</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3" @click="tk(sex)">退款</a>
                          </div>
                          <!--end::Menu item-->
                        </div>
                        <!-- 下拉菜单 - 结束 -->
                      </div>
                      <!--处理状态 - 结束-->
                    </div>
                    <!--end::Toolbar-->
                  </div>
                  <!--end::Card toolbar-->
                  <?php } ?>
                </div>
                <!--end::Card header-->
                <!--begin::Card body-->
                <div v-if="orderList == null" class="card-body pt-0">
                  <div class="text-center px-5">
                    <img src="static/picture/20.png" alt="" class="mw-100 mh-325px">
                    <h1 class="fw-bold mt-5" style="color: #A3A3C7">暂无数据</h1>
                  </div>
                </div>
                <div v-else class="card-body pt-0">
                  <div class="table-responsive">
                    <!--begin::Table-->
                    <table class="table align-middle table-row-dashed fs-6 gy-5">
                      <!--begin::Table head-->
                      <thead>
                        <!--begin::Table row-->
                        <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
                          <th class="w-10px pe-2">
                            <div class="form-check form-check-sm form-check-custom form-check-solid me-3">
                              <input class="form-check-input" type="checkbox" id="checkboxAll" @click="selectAll()">
                            </div>
                          </th>
                          <th class="min-w-20px">ID</th>
                          <th v-if="row.uid==1" class="min-w-20px">UID</th>
                          <th class="min-w-100px">课程名称</th>
                          <th class="min-w-100px">账号</th>
                          <th class="min-w-125px">学习科目</th>
                          <th class="min-w-80px">任务状态</th>
                          <th class="min-w-125px">进度</th>
                          <th class="min-w-50px">备注</th>
                          <th class="min-w-50px">金额</th>
                          <th class="min-w-100px">提交时间</th>
                          <th v-if="row.uid==1" class="min-w-80px">处理状态</th>
                          <th class="text-end min-w-100px">操作</th>
                        </tr>
                        <!--end::Table row-->
                      </thead>
                      <!--end::Table head-->
                      <!--begin::Table body-->
                      <tbody class="text-gray-600 fw-bold">
                        <!--begin::Table row-->
                        <tr v-for="res in orderList">
                          <!--begin::Checkbox-->
                          <td>
                            <div class="form-check form-check-sm form-check-custom form-check-solid">
                              <input class="form-check-input" type="checkbox" id="checkboxAll" :value="res.oid" v-model="sex">
                            </div>
                          </td>
                          <!--end::Checkbox-->
                          <td>{{res.oid}}</td>
                          <td v-if="row.uid==1">{{res.uid}}</td>
                          <td>{{res.ptname}}</td>
                          <td>{{res.user}}</td>
                          <td>{{res.kcname}}</td>
                          <td>
                            <span v-if="res.status=='待处理'" class="badge badge-primary">{{res.status}}</span>
                            <span v-else-if="res.status=='已完成'" class="badge badge-success">{{res.status}}</span>
                            <span v-else-if="res.status=='异常'" class="badge badge-danger">{{res.status}}</span>
                            <span v-else-if="res.status=='进行中'" class="badge badge-warning">{{res.status}}</span>
                            <span v-else class="badge badge-danger">{{res.status}}</span>
                          </td>
                          <td>{{res.process}}</td>
                          <td>{{res.remarks}}</td>
                          <td>{{res.fees}}</td>
                          <td>{{res.addtime}}</td>
                          <td v-if="row.uid==1">
                            <span style="cursor: pointer;" @click="duijie(res.oid)" v-if="res.dockstatus==0" class="badge badge-primary">待处理</span>
                            <span v-if="res.dockstatus==1" class="">处理成功</span>
                            <span style="cursor: pointer;" @click="duijie(res.oid)" v-if="res.dockstatus==2" class="badge badge-danger">处理失败</span>
                            <span v-if="res.dockstatus==3" class="">重复下单</span>
                            <span v-if="res.dockstatus==4" class="">已取消</span>
                            <span v-if="res.dockstatus==99" class="badge badge-warning">我的</span>
                          </td>
                          <!--begin::Action=-->
                          <td class="text-end">
                            <el-dropdown trigger="click" @command="handleMenu">
                              <a href="javascript:;" class="btn btn-sm btn-light btn-active-light-primary">操作
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr072.svg-->
                                <span class="svg-icon svg-icon-5 m-0">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24"
                                    fill="none">
                                    <path
                                      d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z"
                                      fill="black"></path>
                                  </svg>
                                </span>
                                <!--end::Svg Icon-->
                              </a>
                              <template #dropdown>
                                <el-dropdown-menu>
                                  <el-dropdown-item :command="{res,type:'refresh'}">刷新状态</el-dropdown-item>
                                  <el-dropdown-item :command="{res,type:'restart'}">提交补学</el-dropdown-item>
                                  <el-dropdown-item :command="{res,type:'quit'}">取消订单</el-dropdown-item>
                                  <el-dropdown-item :command="{res,type:'check'}">查看详情</el-dropdown-item>
                                </el-dropdown-menu>
                              </template>
                            </el-dropdown>
                          </td>
                          <!--end::Action=-->
                        </tr>
                        <!--end::Table row-->
                      </tbody>
                      <!--end::Table body-->
                    </table>
                    <!--end::Table-->
                  </div>
                  <!-- 分页 - 开始 -->
                  <?php include('./pagination.php'); ?>
                  <!-- 分页 - 结束 -->
                </div>
                <!--end::Card body-->
              </div>
              <!--end::Card-->
              <!-- 订单详情弹窗 - 开始 -->
              <div class="modal fade" id="modal_check" tabindex="-1" aria-hidden="true">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                  <!--begin::Modal content-->
                  <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                      <!--begin::Modal title-->
                      <h3 class="fw-boldest text-dark fs-1 mb-0">订单详情</h3>
                      <!--end::Modal title-->
                      <!--begin::Close-->
                      <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-2x">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                      </div>
                      <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Form-->
                    <form class="form">
                      <!--begin::Modal body-->
                      <div class="modal-body py-10 px-lg-17">
                        <!--begin::Scroll-->
                        <div class="scroll-y me-n7 pe-7" data-kt-scroll="true" data-kt-scroll-max-height="auto" data-kt-scroll-offset="300px">
                          <!--begin::Input group-->
                          <div class="row g-9 mb-5">
                            <!--begin::Col-->
                            <div class="col-md-6 fv-row">
                            <!--begin::Label-->
                              <label class="fs-5 fw-bold mb-2">课程名称</label>
                              <!--end::Label-->
                              <!--begin::Select-->
                              <input type="text" class="form-control form-control-solid" :value="orderInfo.ptname" disabled>
                              <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-md-6 fv-row">
                              <!--begin::Label-->
                              <label class="fs-5 fw-bold mb-2">学校名称</label>
                              <!--end::Label-->
                              <!--begin::Input-->
                              <input type="text" class="form-control form-control-solid" :value="orderInfo.school" disabled>
                              <!--end::Input-->
                            </div>
                            <!--end::Col-->
                          </div>
                          <!--end::Input group-->
                          <!--begin::Input group-->
                          <div class="row g-9 mb-5">
                            <!--begin::Col-->
                            <div class="col-md-6 fv-row">
                              <!--begin::Label-->
                              <label class="fs-5 fw-bold mb-2">下单账号</label>
                              <!--end::Label-->
                              <!--begin::Input-->
                              <input type="text" class="form-control form-control-solid" :value="orderInfo.user" disabled>
                              <!--end::Input-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-md-6 fv-row">
                              <!--begin::Label-->
                              <label class="fs-5 fw-bold mb-2">下单密码</label>
                              <!--end::Label-->
                              <!--begin::Input-->
                              <input type="text" class="form-control form-control-solid" :value="orderInfo.pass" disabled>
                              <!--end::Input-->
                            </div>
                            <!--end::Col-->
                          </div>
                          <!--end::Input group-->
                          <!--begin::Input group-->
                          <div class="mb-5 fv-row">
                            <!--begin::Label-->
                            <label class="fs-5 fw-bold mb-2">下单科目</label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <input type="text" class="form-control form-control-solid" :value="orderInfo.kcname" disabled>
                            <!--end::Input-->
                          </div>
                          <!--end::Input group-->
                          <!--begin::Input group-->
                          <div class="row g-9 mb-5">
                            <!--begin::Col-->
                            <div class="col-md-6 fv-row">
                              <!--begin::Label-->
                              <label class="fs-5 fw-bold mb-2">下单时间</label>
                              <!--end::Label-->
                              <!--begin::Input-->
                              <input type="text" class="form-control form-control-solid" :value="orderInfo.addtime" disabled>
                              <!--end::Input-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-md-6 fv-row">
                              <!--begin::Label-->
                              <label class="fs-5 fw-bold mb-2">订单状态</label>
                              <!--end::Label-->
                              <!--begin::Input-->
                              <input type="text" class="form-control form-control-solid" :value="orderInfo.status" disabled>
                              <!--end::Input-->
                            </div>
                            <!--end::Col-->
                          </div>
                          <!--end::Input group-->
                          <!--begin::Input group-->
                          <div class="row g-9 mb-5" v-if="orderInfo.courseStartTime">
                            <!--begin::Col-->
                            <div class="col-md-6 fv-row">
                              <!--begin::Label-->
                              <label class="fs-5 fw-bold mb-2">课程开始时间</label>
                              <!--end::Label-->
                              <!--begin::Input-->
                              <input type="text" class="form-control form-control-solid" :value="orderInfo.courseStartTime" disabled>
                              <!--end::Input-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-md-6 fv-row" v-if="orderInfo.courseEndTime">
                              <!--begin::Label-->
                              <label class="fs-5 fw-bold mb-2">课程结束时间</label>
                              <!--end::Label-->
                              <!--begin::Input-->
                              <input type="text" class="form-control form-control-solid" :value="orderInfo.courseEndTime" disabled>
                              <!--end::Input-->
                            </div>
                            <!--end::Col-->
                          </div>
                          <!--end::Input group-->
                          <!--begin::Input group-->
                          <div class="row g-9 mb-5" v-if="orderInfo.examStartTime">
                            <!--begin::Col-->
                            <div class="col-md-6 fv-row">
                              <!--begin::Label-->
                              <label class="fs-5 fw-bold mb-2">考试开始时间</label>
                              <!--end::Label-->
                              <!--begin::Input-->
                              <input type="text" class="form-control form-control-solid" :value="orderInfo.examStartTime" disabled>
                              <!--end::Input-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-md-6 fv-row" v-if="orderInfo.examEndTime">
                              <!--begin::Label-->
                              <label class="fs-5 fw-bold mb-2">考试结束时间</label>
                              <!--end::Label-->
                              <!--begin::Input-->
                              <input type="text" class="form-control form-control-solid" :value="orderInfo.examEndTime" disabled>
                              <!--end::Input-->
                            </div>
                            <!--end::Col-->
                          </div>
                          <!--end::Input group-->
                          <!--begin::Input group-->
                          <div class="mb-5 fv-row">
                            <!--begin::Label-->
                            <label class="fs-5 fw-bold mb-2">订单备注</label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <textarea class="form-control form-control-solid" rows="3">{{orderInfo.remarks}}</textarea>
                            <!--end::Input-->
                          </div>
                          <!--end::Input group-->
                          <!--begin::Input group-->
                          <div class="mb-5 fv-row">
                            <!--begin::Label-->
                            <label class="fs-5 fw-bold mb-2">课程进度</label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <textarea class="form-control form-control-solid" rows="3">{{orderInfo.process}}</textarea>
                            <!--end::Input-->
                          </div>
                          <!--end::Input group-->
                        </div>
                        <!--end::Scroll-->
                      </div>
                      <!--end::Modal body-->
                      <!--begin::Modal footer-->
                      <div class="modal-footer flex-center">
                        <!--begin::Button-->
                        <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">关闭</button>
                        <!--end::Button-->
                      </div>
                      <!--end::Modal footer-->
                    </form>
                    <!--end::Form-->
                  </div>
                  <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
              </div>
              <!-- 订单详情弹窗 - 结束 -->
              <!-- 导出订单 - 开始 -->
              <div class="modal fade" id="modal_dcorder" tabindex="-1" aria-hidden="true">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                  <!--begin::Modal content-->
                  <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                      <!--begin::Modal title-->
                      <h3 class="fw-boldest text-dark fs-1 mb-0">导出订单</h3>
                      <!--end::Modal title-->
                      <!--begin::Close-->
                      <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-2x">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                      </div>
                      <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Form-->
                    <form class="form">
                      <!--begin::Modal body-->
                      <div class="modal-body py-10 px-lg-17">
                        <!--begin::Scroll-->
                        <div class="scroll-y me-n7 pe-7" data-kt-scroll="true" data-kt-scroll-max-height="auto" data-kt-scroll-offset="300px">
                          <div v-for="item in dc">{{item}}</div>
                        </div>
                        <!--end::Scroll-->
                      </div>
                      <!--end::Modal body-->
                      <!--begin::Modal footer-->
                      <div class="modal-footer flex-center">
                        <!--begin::Button-->
                        <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal" @click="clearDcList">关闭</button>
                        <!--end::Button-->
                      </div>
                      <!--end::Modal footer-->
                    </form>
                    <!--end::Form-->
                  </div>
                  <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
              </div>
              <!-- 导出订单 - 结束 -->
            </div>
            <!--end::Container-->
          </div>
          <!--end::Post-->
        </div>
        <!--页面主内容 - 结束-->
        <!--页面底部 - 开始-->
        <?php include('./footer.php'); ?>
        <!--页面底部 - 结束-->
      </div>
      <!--end::Wrapper-->
    </div>
    <!--end::Page-->
  </div>
  <!--end::Root-->
  <!-- 底部 - 开始 -->
  <?php require_once('./foot.php'); ?>
  <!-- 底部 - 结束 -->
  <!-- 本页面需要 - 开始 -->
  <script src="static/js/element.js"></script>
  <script src="static/main/pages/list.js"></script>
  <!-- 本页面需要 - 结束 -->
</body>
<!--end::Body-->

</html>