<!DOCTYPE html>
<html lang="zh">
<?php $pagename="账户充值" ?>
<!-- 头部 - 开始 -->
<?php require_once('./head.php');
if($userrow['uuid']!=1){
exit("<script language='javascript'>alert('非站长直属代理，请联系上级充值');window.location.href='./charge';</script>");
}
?>
<!-- 头部 - 结束 -->

<!--begin::Body-->

<body id="kt_body"
  class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled aside-fixed aside-default-enabled">

  <!--begin::Root-->
  <div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="page d-flex flex-row flex-column-fluid">
      <!--侧边栏 - 开始-->
      <?php include('./aside.php'); ?>
      <!--侧边栏 - 结束-->
      <!--begin::Wrapper-->
      <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
        <!--页面头部 - 开始-->
        <?php include('./header.php'); ?>
        <!--页面头部 - 结束-->
        <!--页面主内容 - 开始-->
        <div class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
          <!--begin::Toolbar-->
          <div class="toolbar" id="kt_toolbar">
            <div class="container-fluid d-flex flex-stack flex-wrap flex-sm-nowrap">
              <!--begin::Info-->
              <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                <!--begin::Title-->
                <h1 class="text-dark fw-bolder my-1 fs-2">账户充值</h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb fw-bold fs-base my-1">
                  <li class="breadcrumb-item text-muted">
                    <a href="./index" class="text-muted text-hover-primary">首页</a>
                  </li>
                  <li class="breadcrumb-item text-muted">用户中心</li>
                  <li class="breadcrumb-item text-dark">账户充值</li>
                </ul>
                <!--end::Breadcrumb-->
              </div>
              <!--end::Info-->
              <!--begin::Actions-->
              <div class="d-flex align-items-center flex-nowrap text-nowrap py-1">
                <a href="#" class="btn bg-body btn-color-gray-700 btn-active-primary me-4" data-bs-toggle="modal" data-bs-target="#kt_modal_invite_friends">上级公告</a>
                <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_create_project" id="kt_toolbar_primary_button">用户公告</a>
              </div>
              <!--end::Actions-->
            </div>
          </div>
          <!--end::Toolbar-->
          <!--begin::Post-->
          <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div id="pay" class="container-xxl">
              <!--begin::Stepper-->
              <div class="stepper stepper-pills stepper-column d-flex flex-column flex-xl-row flex-row-fluid" id="kt_create_account_stepper">
                <!--begin::Aside-->
                <div class="d-flex justify-content-center py-10 bg-body rounded justify-content-xl-start flex-row-auto w-100 w-xl-300px w-xxl-400px me-9">
                  <!--begin::Nav-->
                  <div class="stepper-nav d-flex flex-column my-auto mt-10 px-8 px-lg-10 px-xxl-15">
                    <!--begin::Step 1-->
                    <div class="stepper-item current" data-kt-stepper-element="nav">
                      <!--begin::Line-->
                      <div class="stepper-line w-40px"></div>
                      <!--end::Line-->
                      <!--begin::Icon-->
                      <div class="stepper-icon w-40px h-40px">
                        <i class="stepper-check bi bi-check-lg"></i>
                        <span class="stepper-number">1</span>
                      </div>
                      <!--end::Icon-->
                      <!--begin::Label-->
                      <div class="stepper-label">
                        <h3 class="stepper-title">确认信息</h3>
                        <div class="stepper-desc">请确认自己的充值账户</div>
                      </div>
                      <!--end::Label-->
                    </div>
                    <!--end::Step 1-->
                    <!--begin::Step 2-->
                    <div class="stepper-item" data-kt-stepper-element="nav">
                      <!--begin::Line-->
                      <div class="stepper-line w-40px"></div>
                      <!--end::Line-->
                      <!--begin::Icon-->
                      <div class="stepper-icon w-40px h-40px">
                        <i class="stepper-check bi bi-check-lg"></i>
                        <span class="stepper-number">2</span>
                      </div>
                      <!--begin::Icon-->
                      <!--begin::Label-->
                      <div class="stepper-label">
                        <h3 class="stepper-title">充值信息</h3>
                        <div class="stepper-desc">请确认充值金额和支付方式</div>
                      </div>
                      <!--begin::Label-->
                    </div>
                    <!--end::Step 2-->
                    <!--begin::Step 3-->
                    <div class="stepper-item" data-kt-stepper-element="nav">
                      <!--begin::Line-->
                      <div class="stepper-line w-40px"></div>
                      <!--end::Line-->
                      <!--begin::Icon-->
                      <div class="stepper-icon w-40px h-40px">
                        <i class="stepper-check bi bi-check-lg"></i>
                        <span class="stepper-number">3</span>
                      </div>
                      <!--end::Icon-->
                      <!--begin::Label-->
                      <div class="stepper-label">
                        <h3 class="stepper-title">完成支付</h3>
                        <div class="stepper-desc">请您按照提示完成支付</div>
                      </div>
                      <!--end::Label-->
                    </div>
                    <!--end::Step 3-->
                  </div>
                  <!--end::Nav-->
                </div>
                <!--begin::Aside-->
                <!--begin::Content-->
                <div class="d-flex flex-row-fluid flex-center bg-body rounded">
                  <!--begin::Form-->
                  <form class="py-20 w-100 w-xl-600px px-9" action="/epay/epay.php" method="post" novalidate="novalidate" id="kt_create_account_form">
                    <!--begin::Step 1-->
                    <div class="current" data-kt-stepper-element="content">
                      <!--begin::Wrapper-->
                      <div class="w-100">
                        <!--begin::Heading-->
                        <div class="pb-10 pb-lg-10">
                          <!--begin::Title-->
                          <h1 class="fw-boldest text-dark">确认信息</h1>
                          <!--end::Title-->
                          <!--begin::Notice-->
                          <div class="text-gray-400 fw-bold fs-4">如有疑问请立即停止操作</div>
                          <!--end::Notice-->
                        </div>
                        <!--end::Heading-->
                        <div class="d-flex justify-content-center">
                        <img style="border-radius:50%;" src="http://q2.qlogo.cn/headimg_dl?dst_uin=<?php echo $userrow['user']?>&spec=100" alt="用户头像">
                        </div>
                        <!--begin::Input group-->
                        <div class="mb-5 fv-row">
                          <!--begin::Label-->
                          <label class="fs-5 fw-bold mb-2">用户账号</label>
                          <!--end::Label-->
                          <!--begin::Input-->
                          <input type="text" class="form-control form-control-solid" placeholder="请输入用户账号" value="<?php echo $userrow['user'] ?>" disabled>
                          <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="mb-5 fv-row">
                          <!--begin::Label-->
                          <label class="fs-5 fw-bold mb-2">账户余额</label>
                          <!--end::Label-->
                          <!--begin::Input-->
                          <input type="text" class="form-control form-control-solid" placeholder="请输入账户余额" value="<?php echo $userrow['money'] ?>" disabled>
                          <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                      </div>
                      <!--end::Wrapper-->
                    </div>
                    <!--end::Step 1-->
                    <!--begin::Step 2-->
                    <div data-kt-stepper-element="content">
                      <!--begin::Wrapper-->
                      <div class="w-100">
                        <!--begin::Heading-->
                        <div class="pb-10 pb-lg-10">
                          <!--begin::Title-->
                          <h1 class="fw-boldest text-dark">充值信息</h1>
                          <!--end::Title-->
                          <!--begin::Notice-->
                          <div class="text-gray-400 fw-bold fs-4">如有疑问请立即停止操作</div>
                          <!--end::Notice-->
                        </div>
                        <!--end::Heading-->
                        <!--begin::Input group-->
                        <input type="hidden" name="out_trade_no" :value="out_trade_no"/>
                        <div class="mb-10 fv-row">
                          <!--begin::Label-->
                          <label class="fs-6 fw-bold form-label mb-3">充值金额</label>
                          <!--end::Label-->
                          <!--begin::Input-->
                          <input type="text" v-model="money" name="money" class="form-control form-control-lg form-control-solid" placeholder="请输入充值金额">
                          <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="mb-0 fv-row">
                          <!--begin::Label-->
                          <label class="d-flex align-items-center fs-6 fw-bold form-label mb-5">支付方式 
                          <i class="bi bi-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="大额请选择支付宝"></i></label>
                          <!--end::Label-->
                          <!--begin::Options-->
                          <div class="mb-0">
                            <?php if($conf['is_alipay']==1){ ?>
                            <!--begin:Option-->
                            <label class="d-flex flex-stack mb-5 cursor-pointer">
                              <!--begin:Label-->
                              <span class="d-flex align-items-center me-2">
                                <!--begin::Icon-->
                                <span class="symbol symbol-50px me-6">
                                  <span class="symbol-label">
                                    <!--begin::Svg Icon | path: icons/duotune/general/gen024.svg-->
                                    <span class="svg-icon svg-icon-1 svg-icon-gray-600">
                                    <svg t="1678535152081" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4597" width="200" height="200"><path d="M962.094068 708.500373c-36.895305-11.231809-262.625396-80.057337-315.641867-99.172697 34.775015-59.368132 62.512752-127.337153 80.763418-201.375403L528.363689 407.952272l0-67.038836 243.819075 0 0-41.079604L528.363689 299.833833 528.363689 187.957813l-93.7635 0c-16.842597 0-18.875906 15.172561-18.875906 15.172561l0 96.703459L187.030697 299.833833l0 41.079604 228.693586 0 0 67.038836L228.247424 407.952272l0 37.334303 378.886283 0c-13.938454 47.215348-32.311917 91.569532-54.394864 131.881656-85.460394-28.045753-133.401266-47.514153-238.20624-57.277518C115.726721 501.288031 69.90614 609.776907 62.775742 676.122965 52.018747 777.185708 142.033877 859.815637 276.93224 859.815637c134.859477 0 224.354767-61.769832 309.813115-164.668387 109.49581 51.92358 373.496529 165.473729 373.496529 165.473729L962.094068 708.500373 962.094068 708.500373 962.094068 708.500373 962.094068 708.500373zM262.034948 795.805788c-142.527111 0-165.101245-89.446171-157.502174-126.849036 7.43125-37.238113 48.712445-85.704964 127.98593-85.704964 91.039459 0 172.597987 23.096021 270.493597 70.495564C434.246125 742.758618 349.745592 795.805788 262.034948 795.805788L262.034948 795.805788 262.034948 795.805788 262.034948 795.805788z" fill="#5D5D5D" p-id="4598"></path></svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                  </span>
                                </span>
                                <!--end::Icon-->
                                <!--begin::Description-->
                                <span class="d-flex flex-column">
                                  <span class="fw-boldest text-gray-800 text-hover-primary fs-4">支付宝</span>
                                  <span class="fs-6 fw-bold text-gray-400">使用支付宝进行充值</span>
                                </span>
                                <!--end:Description-->
                              </span>
                              <!--end:Label-->
                              <!--begin:Input-->
                              <span class="form-check form-check-custom form-check-solid">
                                <input class="form-check-input" type="radio" name="type" value="alipay">
                              </span>
                              <!--end:Input-->
                            </label>
                            <!--end::Option-->
                            <?php } ?>
                            <?php if($conf['is_qqpay']==1){ ?>
                            <!--begin:Option-->
                            <label class="d-flex flex-stack mb-5 cursor-pointer">
                              <!--begin:Label-->
                              <span class="d-flex align-items-center me-2">
                                <!--begin::Icon-->
                                <span class="symbol symbol-50px me-6">
                                  <span class="symbol-label">
                                    <!--begin::Svg Icon | path: icons/duotune/art/art006.svg-->
                                    <span class="svg-icon svg-icon-1 svg-icon-gray-600">
                                      <svg t="1678535103130" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3613" width="200" height="200"><path d="M116.435 593.714c-33.54 78.964-38.985 154.297-12.059 168.37 18.572 9.696 47.686-12.382 74.936-52.909 10.791 44.157 37.493 84.137 75.633 116.21-40.004 14.768-66.135 38.886-66.135 66.232 0 44.954 70.709 81.302 157.978 81.302 78.716 0 143.907-29.538 155.94-68.371 3.232-0.049 15.663-0.049 18.796 0 12.083 38.784 77.324 68.371 155.989 68.371 87.267 0 157.978-36.398 157.978-81.302 0-27.297-26.105-51.464-66.135-66.232 38.089-32.123 64.889-72.053 75.631-116.21 27.251 40.527 56.29 62.605 74.887 52.909 26.95-14.073 21.631-89.456-12.032-168.37-26.355-62.058-62.11-107.754-89.457-117.848 0.398-3.929 0.596-7.958 0.596-11.935 0-23.968-6.661-46.146-18.049-64.196 0.199-1.393 0.199-2.834 0.199-4.227 0-11.038-2.636-21.381-7.114-30.332-6.909-161.309-111.93-289.402-281.866-289.402-170.036 0-275.106 128.093-281.943 289.402-4.525 9.001-7.135 19.343-7.135 30.332 0 1.393 0.099 2.835 0.15 4.227-11.288 18.05-17.951 40.178-17.951 64.196 0 3.978 0.15 7.955 0.498 11.935-27.151 10.094-63.028 55.841-89.333 117.848z" fill="#272636" p-id="3614"></path></svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                  </span>
                                </span>
                                <!--end::Icon-->
                                <!--begin::Description-->
                                <span class="d-flex flex-column">
                                  <span class="fw-boldest text-gray-800 text-hover-primary fs-4">QQ支付</span>
                                  <span class="fs-6 fw-bold text-gray-400">使用QQ支付进行充值</span>
                                </span>
                                <!--end:Description-->
                              </span>
                              <!--end:Label-->
                              <!--begin:Input-->
                              <span class="form-check form-check-custom form-check-solid">
                                <input class="form-check-input" type="radio" name="type" value="qqpay">
                              </span>
                              <!--end:Input-->
                            </label>
                            <!--end::Option-->
                            <?php } ?>
                            <?php if($conf['is_wxpay']==1){ ?>
                            <!--begin:Option-->
                            <label class="d-flex flex-stack mb-0 cursor-pointer">
                              <!--begin:Label-->
                              <span class="d-flex align-items-center me-2">
                                <!--begin::Icon-->
                                <span class="symbol symbol-50px me-6">
                                  <span class="symbol-label">
                                    <!--begin::Svg Icon | path: icons/duotune/general/gen032.svg-->
                                    <span class="svg-icon svg-icon-1 svg-icon-gray-600">
                                    <svg t="1678535177429" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5578" width="200" height="200"><path d="M232.066915 904.023488l97.608062-56.365752c7.351432-4.247744 15.146978-6.882757 23.724331-6.882757 4.50971 0 8.916067 0.756223 13.06148 2.00875 45.571918 13.06148 94.688569 20.334117 145.552004 20.334117 246.261707 0 445.858604-166.382425 445.858604-371.531781 0-62.204737-18.431791-120.707153-50.732451-172.195827L393.756457 615.839996l-3.28379 1.823532c-4.041036 2.060939-8.550747 3.181459-13.374612 3.181459-11.131525 0-20.856004-6.076392-25.966395-15.20019l-1.928932-4.249791-81.158415-178.088024c-0.860601-2.006703-1.433652-4.197602-1.433652-6.308683 0-8.212032 6.674003-14.83487 14.859429-14.83487 3.337002 0 6.414083 1.069355 8.916067 2.946099l95.756901 68.200288c7.012717 4.561899 15.35471 7.247054 24.376177 7.247054 5.370311 0 10.454096-0.99056 15.22475-2.737344L876.219747 277.338493c-80.715323-95.157243-213.726709-157.361981-364.206956-157.361981-246.235101 0-445.884187 166.382425-445.884187 371.609553 0 111.921046 60.067051 212.736149 154.050562 280.806477 7.586792 5.449106 12.514012 14.261818 12.514012 24.219611 0 3.311419-0.704035 6.309706-1.564635 9.489118-7.507998 27.974122-19.552312 72.840982-20.074198 74.978668-0.938372 3.492544-2.424212 7.117095-2.424212 10.819416" fill="#31AC37" p-id="5579"></path></svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                  </span>
                                </span>
                                <!--end::Icon-->
                                <!--begin::Description-->
                                <span class="d-flex flex-column">
                                  <span class="fw-boldest text-gray-800 text-hover-primary fs-4">微信支付</span>
                                  <span class="fs-6 fw-bold text-gray-400">使用微信支付进行充值</span>
                                </span>
                                <!--end:Description-->
                              </span>
                              <!--end:Label-->
                              <!--begin:Input-->
                              <span class="form-check form-check-custom form-check-solid">
                                <input class="form-check-input" type="radio" name="type" value="wxpay">
                              </span>
                              <!--end:Input-->
                            </label>
                            <!--end::Option-->
                            <?php } ?>
                          </div>
                          <!--end::Options-->
                        </div>
                        <!--end::Input group-->
                      </div>
                      <!--end::Wrapper-->
                    </div>
                    <!--end::Step 2-->
                    <!--begin::Step 3-->
                    <div data-kt-stepper-element="content" class="finish">
												<!--begin::Wrapper-->
												<div class="w-100">
													<!--begin::Heading-->
													<div class="pb-8 pb-lg-12">
														<!--begin::Title-->
														<h1 class="fw-boldest text-dark">完成支付</h1>
														<!--end::Title-->
														<!--begin::Notice-->
														<div class="text-gray-400 fw-bold fs-4">如有疑问请立即停止操作</div>
														<!--end::Notice-->
													</div>
													<!--end::Heading-->
													<!--begin::Body-->
													<div class="pt-1 pb-5">
														<!--begin::Alert-->
														<!--begin::Notice-->
														<div class="notice d-flex bg-light-warning rounded border-warning border border-dashed p-6">
															<!--begin::Icon-->
															<!--begin::Svg Icon | path: icons/duotune/general/gen044.svg-->
															<span class="svg-icon svg-icon-2tx svg-icon-warning me-4">
																<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
																	<rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
																	<rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
																	<rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
																</svg>
															</span>
															<!--end::Svg Icon-->
															<!--end::Icon-->
															<!--begin::Wrapper-->
															<div class="d-flex flex-stack flex-grow-1">
																<!--begin::Content-->
																<div class="fw-bold">
																	<h4 class="text-gray-900 fw-bolder">温馨提示!</h4>
																	<div class="fs-6 text-gray-700">如您已完成支付后为自动跳转请自行刷新网页。</div>
																</div>
																<!--end::Content-->
															</div>
															<!--end::Wrapper-->
														</div>
														<!--end::Notice-->
														<!--end::Alert-->
													</div>
													<!--end::Body-->
												</div>
												<!--end::Wrapper-->
											</div>
                    <!--end::Step 3-->
                    <!--begin::Actions-->
                    <div class="d-flex flex-stack pt-10">
                      <!--begin::Wrapper-->
                      <div class="mr-2">
                        <button type="button" class="btn btn-lg btn-light-primary me-3" data-kt-stepper-action="previous">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr063.svg-->
                        <span class="svg-icon svg-icon-4 me-1">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="11" width="13" height="2" rx="1" fill="black"></rect>
                            <path d="M8.56569 11.4343L12.75 7.25C13.1642 6.83579 13.1642 6.16421 12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75L5.70711 11.2929C5.31658 11.6834 5.31658 12.3166 5.70711 12.7071L11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25C13.1642 17.8358 13.1642 17.1642 12.75 16.75L8.56569 12.5657C8.25327 12.2533 8.25327 11.7467 8.56569 11.4343Z" fill="black"></path>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->返回</button>
                      </div>
                      <!--end::Wrapper-->
                      <!--begin::Wrapper-->
                      <div>
                        <button type="submit" class="btn btn-lg btn-primary me-3" data-kt-stepper-action="submit">
                          <span class="indicator-label">去支付 
                          <!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
                          <span class="svg-icon svg-icon-3 ms-2 me-0">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                              <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                              <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                            </svg>
                          </span>
                          <!--end::Svg Icon--></span>
                          <span class="indicator-progress">Please wait... 
                          <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                        <button type="button" class="btn btn-lg btn-primary" data-kt-stepper-action="next">下一步 
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
                        <span class="svg-icon svg-icon-4 ms-1 me-0">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                            <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                          </svg>
                        </span>
                        <!--end::Svg Icon--></button>
                      </div>
                      <!--end::Wrapper-->
                    </div>
                    <!--end::Actions-->
                  </form>
                  <!--end::Form-->
                </div>
                <!--end::Content-->
              </div>
              <!--end::Stepper-->
            </div>
            <!--end::Container-->
          </div>
          <!--end::Post-->
        </div>
        <!--页面主内容 - 结束-->
        <!--页面底部 - 开始-->
        <?php include('./footer.php'); ?>
        <!--页面底部 - 结束-->
      </div>
      <!--end::Wrapper-->
    </div>
    <!--end::Page-->
  </div>
  <!--end::Root-->
  <!-- 底部 - 开始 -->
  <?php require_once('./foot.php'); ?>
  <!-- 底部 - 结束 -->
  <!-- 本页面需要 - 开始 -->
  <script src="static/main/pages/pay.js"></script>
  <!-- 本页面需要 - 结束 -->
</body>
<!--end::Body-->

</html>