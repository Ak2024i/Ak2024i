<!DOCTYPE html>
<html lang="zh">
<?php $pagename="代理管理" ?>
<!-- 头部 - 开始 -->
<?php require_once('./head.php'); ?>
<!-- 头部 - 结束 -->

<!--begin::Body-->

<body id="kt_body"
  class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled aside-fixed aside-default-enabled">

  <!--begin::Root-->
  <div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="page d-flex flex-row flex-column-fluid">
      <!--侧边栏 - 开始-->
      <?php include('./aside.php'); ?>
      <!--侧边栏 - 结束-->
      <!--begin::Wrapper-->
      <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
        <!--页面头部 - 开始-->
        <?php include('./header.php'); ?>
        <!--页面头部 - 结束-->
        <!--页面主内容 - 开始-->
        <div class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
          <!--begin::Toolbar-->
          <div class="toolbar" id="kt_toolbar">
            <div class="container-fluid d-flex flex-stack flex-wrap flex-sm-nowrap">
              <!--begin::Info-->
              <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                <!--begin::Title-->
                <h1 class="text-dark fw-bolder my-1 fs-2"><?php echo $pagename ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb fw-bold fs-base my-1">
                  <li class="breadcrumb-item text-muted">
                    <a href="./index" class="text-muted text-hover-primary">首页</a>
                  </li>
                  <li class="breadcrumb-item text-muted">用户中心</li>
                  <li class="breadcrumb-item text-dark"><?php echo $pagename ?></li>
                </ul>
                <!--end::Breadcrumb-->
              </div>
              <!--end::Info-->
              <!--begin::Actions-->
              <div class="d-flex align-items-center flex-nowrap text-nowrap py-1">
                <a href="JavaScript:;" class="btn bg-body btn-color-gray-700 btn-active-primary me-4" data-bs-toggle="modal" data-bs-target="#modal_usernotice">站点公告</a>
                <a href="JavaScript:;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_tcgonggao">重要通知</a>
              </div>
              <!--end::Actions-->
            </div>
          </div>
          <!--end::Toolbar-->
          <!--begin::Post-->
          <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div id="userlist" class="container-xxl">
              <!--begin::Card-->
              <div class="card card-flush">
                <!--begin::Card header-->
                <div class="card-header mt-6">
                  <!--begin::Card title-->
                  <div class="card-title">
                    <!--begin::Select-->
                    <div class="me-6 my-1">
                      <select v-model="type" data-hide-search="true" class="w-125px form-select form-select-solid">
                        <option value="1">UID</option>
				                <option value="2">用户名</option>
				                <option value="3">邀请码</option>
				                <option value="4">昵称</option>
				                <option value="5">费率</option>
				                <option value="6">余额</option>
				                <option value="7">最后在线时间</option>
                      </select>
                    </div>
                    <!--end::Select-->
                    <!--begin::Search-->
                    <div class="d-flex align-items-center position-relative my-1 me-5">
                      <!--begin::Svg Icon | path: icons/duotune/general/gen021.svg-->
                      <span class="svg-icon svg-icon-1 position-absolute ms-6">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                          <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="black"></rect>
                          <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="black"></path>
                        </svg>
                      </span>
                      <!--end::Svg Icon-->
                      <input type="text" v-model="qq" data-kt-permissions-table-filter="search" class="form-control form-control-solid w-250px ps-15" placeholder="Search...">
                    </div>
                    <!--end::Search-->
                    <!--begin::Action-->
                    <button type="button" @click="get(1,1)" class="btn btn-primary btn-icon flex-shrink-0">
                      <!--begin::Svg Icon | path: icons/duotune/arrows/arr065.svg-->
                      <span class="svg-icon svg-icon-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                          <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="black"></rect>
                          <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="black"></path>
                        </svg>
                      </span>
                      <!--end::Svg Icon-->
                    </button>
                    <!--end::Action-->
                  </div>
                  <!--end::Card title-->
                  <!--begin::Card toolbar-->
                  <div class="card-toolbar">
                    <!--begin::Toolbar-->
                    <div class="d-flex justify-content-end" data-kt-user-table-toolbar="base">
                      <!--begin::Export-->
                      <button type="button" class="btn btn-light-primary me-3" data-bs-toggle="modal" data-bs-target="#modal_add">
                      <!--begin::Svg Icon | path: icons/duotune/arrows/arr078.svg-->
                      <span class="svg-icon svg-icon-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
													<rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="black"></rect>
													<rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="black"></rect>
													<rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="black"></rect>
												</svg>
                      </span>
                      <!--end::Svg Icon-->添加用户</button>
                      <!--end::Export-->
                    </div>
                    <!--end::Toolbar-->
                  </div>
                  <!--end::Card toolbar-->
                </div>
                <!--end::Card header-->
                <!--begin::Card body-->
                <div v-if="userList == null" class="card-body pt-0">
                  <div class="text-center px-5">
                    <img src="static/picture/20.png" alt="" class="mw-100 mh-325px">
                    <h1 class="fw-bold mt-5" style="color: #A3A3C7">暂无数据</h1>
                  </div>
                </div>
                <div v-else class="card-body pt-0">
                  <div class="table-responsive">
                    <!--begin::Table-->
                    <table class="table align-middle table-row-dashed fs-6 gy-5 mb-0">
												<!--begin::Table head-->
												<thead>
													<!--begin::Table row-->
													<tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
                            <th class="min-w-50px">ID</th>
                            <th class="min-w-125px">用户信息</th>
                            <th class="min-w-100px">账户余额</th>
                            <th class="min-w-80px">用户费率</th>
                            <th class="min-w-125px">对接密钥</th>
                            <th class="min-w-125px">邀请码</th>
                            <th class="min-w-125px">账户状态</th>
                            <th class="min-w-125px">最近在线</th>
                            <th class="text-end min-w-100px">项目操作</th>
													</tr>
													<!--end::Table row-->
												</thead>
												<!--end::Table head-->
												<!--begin::Table body-->
												<tbody class="fw-bold text-gray-600">
                          <tr v-for="res in userList" :key="res.uid">
                            <td>{{res.uid}}</td>
                            <!--begin::User=-->
                            <td class="d-flex align-items-center">
                              <!--begin:: Avatar -->
                              <div class="symbol symbol-circle symbol-50px overflow-hidden me-3">
                                <a href="javascript:;">
                                  <div class="symbol-label">
                                    <img :src="'http://q2.qlogo.cn/headimg_dl?dst_uin=' + res.user + '&spec=100'" alt="用户头像" class="w-100">
                                  </div>
                                </a>
                              </div>
                              <!--end::Avatar-->
                              <!--begin::User details-->
                              <div class="d-flex flex-column">
                                <a href="javascript:;" class="text-gray-800 text-hover-primary mb-1">{{res.name}}</a>
                                <span>{{res.user}}</span>
                              </div>
                              <!--begin::User details-->
                            </td>
                            <!--end::User=-->
                            <td>{{res.money}}</td>
                            <td>{{res.addprice}}</td>
                            <td><span class="badge badge-success" v-if="res.key==1">已开通</span><span style="cursor: pointer;" class="badge badge-danger" v-else-if="res.key==0" @click="ktapi(res.uid)">未开通</span></td>
                            <td><span style="cursor: pointer;" class="badge badge-warning" @click="yqm(res)">{{res.yqm==''?'无':res.yqm}}</span></td>
                            <td><span style="cursor: pointer;" class="badge badge-success" v-if="res.active==1" @click="ban(res.uid,res.active)">正常</span><span style="cursor: pointer;" class="badge badge-danger" v-else-if="res.active==0" @click="ban(res.uid,res.active)">封禁</span></td>
                            <td>{{res.endtime}}</td>
                            <!--begin::Action=-->
														<td class="text-end">
                              <el-dropdown trigger="click" @command="handleMenu">
                                <a href="javascript:;" class="btn btn-sm btn-light btn-active-light-primary">操作
                                  <!--begin::Svg Icon | path: icons/duotune/arrows/arr072.svg-->
                                  <span class="svg-icon svg-icon-5 m-0">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24"
                                      fill="none">
                                      <path
                                        d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z"
                                        fill="black"></path>
                                    </svg>
                                  </span>
                                  <!--end::Svg Icon-->
                                </a>
                                <template #dropdown>
                                  <el-dropdown-menu>
                                    <el-dropdown-item :command="{res,type:'cz'}">充值余额</el-dropdown-item>
                                    <el-dropdown-item :command="{res,type:'changeLevel'}">修改等级</el-dropdown-item>
                                    <el-dropdown-item :command="{res,type:'czmm'}">重置密码</el-dropdown-item>
                                  </el-dropdown-menu>
                                </template>
                              </el-dropdown>
														</td>
														<!--end::Action=-->
                          </tr>
												</tbody>
												<!--end::Table body-->
											</table>
                    <!--end::Table-->
                  </div>
                  <!-- 分页 - 开始 -->
                  <?php include('./pagination.php'); ?>
                  <!-- 分页 - 结束 -->
                </div>
                <!--end::Card body-->
              </div>
              <!--end::Card-->
              <!--添加弹窗 - 开始-->
              <div class="modal fade" id="modal_add" tabindex="-1" aria-hidden="true">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                  <!--begin::Modal content-->
                  <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                      <!--begin::Modal title-->
                      <h3 class="fw-boldest text-dark fs-1 mb-0">添加用户</h3>
                      <!--end::Modal title-->
                      <!--begin::Close-->
                      <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-2x">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                      </div>
                      <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Form-->
                    <form class="form" @submit.prevent="">
                      <!--begin::Modal body-->
                      <div class="modal-body py-10 px-lg-17">
                        <!--begin::Scroll-->
                        <div class="scroll-y me-n7 pe-7" data-kt-scroll="true" data-kt-scroll-max-height="auto" data-kt-scroll-offset="300px">
                          <!--begin::Input group-->
                          <div class="mb-1 fv-row d-flex justify-content-center">
                            <!--begin::Preview existing avatar-->
                            <img :src="'http://q2.qlogo.cn/headimg_dl?dst_uin=' + addForm.user + '&spec=100'" onerror="javascript:this.src='static/image/blank.png';" style="width:100px;border-radius: 50%;" alt="">
                            <!--end::Preview existing avatar-->
                          </div>
                          <!--end::Input group-->
                          <!--begin::Input group-->
                          <div class="mb-5 fv-row">
                            <!--begin::Label-->
                            <label class="required fs-5 fw-bold mb-2">用户昵称</label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <input type="text" v-model="addForm.name" class="form-control form-control-solid" placeholder="请输入用户昵称">
                            <!--end::Input-->
                          </div>
                          <!--end::Input group-->
                          <!--begin::Input group-->
                          <div class="mb-5 fv-row">
                            <!--begin::Label-->
                            <label class="required fs-5 fw-bold mb-2">用户账号</label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <input type="text" v-model="addForm.user" class="form-control form-control-solid" placeholder="请输入用户账号">
                            <!--end::Input-->
                          </div>
                          <!--end::Input group-->
                          <!--begin::Input group-->
                          <div class="mb-5 fv-row">
                            <!--begin::Label-->
                            <label class="required fs-5 fw-bold mb-2">用户密码</label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <input type="text" v-model="addForm.pass" class="form-control form-control-solid" placeholder="请输入用户密码">
                            <!--end::Input-->
                          </div>
                          <!--end::Input group-->
                          <!--begin::Input group-->
                          <div class="mb-5 fv-row">
                            <!--begin::Label-->
                            <label class="required fs-5 fw-bold mb-2">用户等级</label>
                            <!--end::Label-->
                            <!--begin::Select-->
                            <select v-model="addForm.addprice" data-hide-search="true" data-placeholder="请选择用户等级..." class="form-select form-select-solid">
                              <option v-for="row2 in row1.data" :value="row2.rate">{{row2.name}} [费率:{{row2.rate}}]</option>
                            </select>
                            <!--end::Select-->
                          </div>
                          <!--end::Input group-->
                        </div>
                        <!--end::Scroll-->
                      </div>
                      <!--end::Modal body-->
                      <!--begin::Modal footer-->
                      <div class="modal-footer flex-center">
                        <!--begin::Button-->
                        <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">取消</button>
                        <!--end::Button-->
                        <!--begin::Button-->
                        <button type="button" id="addSubmitBtn" @click="handleAdd()" class="btn btn-primary">
                          <span class="indicator-label">确认提交</span>
                          <span class="indicator-progress">Please wait... 
                          <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                        <!--end::Button-->
                      </div>
                      <!--end::Modal footer-->
                    </form>
                    <!--end::Form-->
                  </div>
                  <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
              </div>
              <!--添加弹窗 - 结束-->
              <!--修改等级弹窗 - 开始-->
              <div class="modal fade" id="modal_update" tabindex="-1" aria-hidden="true">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                  <!--begin::Modal content-->
                  <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                      <!--begin::Modal title-->
                      <h3 class="fw-boldest text-dark fs-1 mb-0">修改等级</h3>
                      <!--end::Modal title-->
                      <!--begin::Close-->
                      <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-2x">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                      </div>
                      <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Form-->
                    <form class="form" @submit.prevent="">
                      <!--begin::Modal body-->
                      <div class="modal-body py-10 px-lg-17">
                        <!--begin::Scroll-->
                        <div class="scroll-y me-n7 pe-7" data-kt-scroll="true" data-kt-scroll-max-height="auto" data-kt-scroll-offset="300px">
                          <!--begin::Input group-->
                          <div class="mb-5 fv-row">
                            <!--begin::Label-->
                            <label class="required fs-5 fw-bold mb-2">用户等级</label>
                            <!--end::Label-->
                            <!--begin::Select-->
                            <select v-model="updateForm.addprice" data-hide-search="true" data-placeholder="请选择用户等级..." class="form-select form-select-solid">
                              <option v-for="row2 in row1.data" :value="row2.rate">{{row2.name}} [费率:{{row2.rate}}]</option>
                            </select>
                            <!--end::Select-->
                          </div>
                          <!--end::Input group-->
                        </div>
                        <!--end::Scroll-->
                      </div>
                      <!--end::Modal body-->
                      <!--begin::Modal footer-->
                      <div class="modal-footer flex-center">
                        <!--begin::Button-->
                        <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">取消</button>
                        <!--end::Button-->
                        <!--begin::Button-->
                        <button type="button" id="updateSubmitBtn" @click="handleUpdate()" class="btn btn-primary">
                          <span class="indicator-label">确认提交</span>
                          <span class="indicator-progress">Please wait... 
                          <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                        <!--end::Button-->
                      </div>
                      <!--end::Modal footer-->
                    </form>
                    <!--end::Form-->
                  </div>
                  <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
              </div>
              <!--修改等级弹窗 - 结束-->
              <!--邀请码弹窗 - 开始-->
              <div class="modal fade" id="modal_yqm" tabindex="-1" aria-hidden="true">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                  <!--begin::Modal content-->
                  <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                      <!--begin::Modal title-->
                      <h3 class="fw-boldest text-dark fs-1 mb-0">开通邀请码</h3>
                      <!--end::Modal title-->
                      <!--begin::Close-->
                      <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-2x">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)"
                              fill="black"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black">
                            </rect>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                      </div>
                      <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                      <!--begin::Form-->
                      <form class="form" action="#" @submit.prevent="">
                        <!--begin::Input group-->
                        <div class="d-flex flex-column mb-7 fv-row">
                          <input v-model="yqmInfo.yqm" type="text"
                            class="form-control form-control-solid" placeholder="请输入最低4位邀请码" autocomplete="off">
                        </div>
                        <!--end::Input group-->
                        <div class="text-gray-600">您正在为 <font color="red">{{yqmInfo.name}}</font> 设置邀请码</div>
                        <!--begin::Actions-->
                        <div class="text-center pt-15">
                          <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">取消</button>
                          <button id="yqmBtn" type="button" class="btn btn-primary"><span
                              class="indicator-label">确认提交</span>
                            <span class="indicator-progress">Please wait...
                              <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span></button>
                        </div>
                        <!--end::Actions-->
                      </form>
                      <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                  </div>
                  <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
              </div>
              <!--邀请码弹窗 - 结束-->
              <!--账户充值 - 开始-->
              <div class="modal fade" id="modal_zhcz" tabindex="-1" aria-hidden="true">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                  <!--begin::Modal content-->
                  <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                      <!--begin::Modal title-->
                      <h3 class="fw-boldest text-dark fs-1 mb-0">账户充值</h3>
                      <!--end::Modal title-->
                      <!--begin::Close-->
                      <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-2x">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)"
                              fill="black"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black">
                            </rect>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                      </div>
                      <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                      <!--begin::Form-->
                      <form class="form" action="#" @submit.prevent="">
                        <!--begin::Input group-->
                        <div class="d-flex flex-column mb-7 fv-row">
                          <input v-model="czInfo.money" type="text"
                            class="form-control form-control-solid" placeholder="请输入需要充值的金额" autocomplete="off">
                        </div>
                        <!--end::Input group-->
                        <div class="text-gray-600">您正在为 <font color="red">{{czInfo.name}}</font> 充值余额</div>
                        <!--begin::Actions-->
                        <div class="text-center pt-15">
                          <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">取消</button>
                          <button id="czBtn" type="button" class="btn btn-primary"><span
                              class="indicator-label">确认提交</span>
                            <span class="indicator-progress">Please wait...
                              <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span></button>
                        </div>
                        <!--end::Actions-->
                      </form>
                      <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                  </div>
                  <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
              </div>
              <!--账户充值 - 结束-->
            </div>
            <!--end::Container-->
          </div>
          <!--end::Post-->
        </div>
        <!--页面主内容 - 结束-->
        <!--页面底部 - 开始-->
        <?php include('./footer.php'); ?>
        <!--页面底部 - 结束-->
      </div>
      <!--end::Wrapper-->
    </div>
    <!--end::Page-->
  </div>
  <!--end::Root-->
  <!-- 底部 - 开始 -->
  <?php require_once('./foot.php'); ?>
  <!-- 底部 - 结束 -->
  <!-- 本页面需要 - 开始 -->
  <script src="static/js/element.js"></script>
  <script src="static/main/pages/userlist.js"></script>
  <!-- 本页面需要 - 结束 -->
</body>
<!--end::Body-->

</html>