<!DOCTYPE html>
<html lang="zh">
<?php $pagename="用户中心" ?>
<!-- 头部 - 开始 -->
<?php require_once('./head.php'); ?>
<!-- 头部 - 结束 -->

<!--begin::Body-->

<body id="kt_body"
  class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled aside-fixed aside-default-enabled">

  <!--begin::Root-->
  <div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="page d-flex flex-row flex-column-fluid">
      <!--侧边栏 - 开始-->
      <?php include('./aside.php'); ?>
      <!--侧边栏 - 结束-->
      <!--begin::Wrapper-->
      <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
        <!--页面头部 - 开始-->
        <?php include('./header.php'); ?>
        <!--页面头部 - 结束-->
        <!--页面主内容 - 开始-->
        <div class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
          <!--begin::Toolbar-->
          <div class="toolbar" id="kt_toolbar">
            <div class="container-fluid d-flex flex-stack flex-wrap flex-sm-nowrap">
              <!--begin::Info-->
              <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                <!--begin::Title-->
                <h1 class="text-dark fw-bolder my-1 fs-2">用户中心 
                <small class="text-muted fs-6 fw-normal ms-1"></small></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb fw-bold fs-base my-1">
                  <li class="breadcrumb-item text-muted">
                    <a href="./index" class="text-muted text-hover-primary">首页</a>
                  </li>
                  <li class="breadcrumb-item text-muted">用户中心</li>
                </ul>
                <!--end::Breadcrumb-->
              </div>
              <!--end::Info-->
              <!--begin::Actions-->
              <div class="d-flex align-items-center flex-nowrap text-nowrap py-1">
                <a href="JavaScript:;" class="btn bg-body btn-color-gray-700 btn-active-primary me-4" data-bs-toggle="modal" data-bs-target="#modal_usernotice">站点公告</a>
                <a href="JavaScript:;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_tcgonggao">重要通知</a>
              </div>
              <!--end::Actions-->
            </div>
          </div>
          <!--end::Toolbar-->
          <!--begin::Post-->
          <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div id="home" class="container-xxl">
              <!--begin::Row-->
              <div class="row g-xl-8">
                <!--资料卡 - 开始-->
                <div class="col-xxl-4 gy-0 gy-xxl-8">
                  <!--begin::Engage Widget 1-->
                  <div class="card card-xxl-stretch mb-5 mb-xl-8">
                    <!--begin::Body-->
                    <div class="card-body pb-0">
                      <!--begin::Wrapper-->
                      <div class="d-flex flex-center flex-column h-100">
                        <div class="symbol symbol-100px symbol-circle mb-5">
                          <img src="http://q2.qlogo.cn/headimg_dl?dst_uin=<?=$userrow['user'];?>&spec=100" alt="image">
                        </div>
                        <a href="javascript:;" class="fs-3 text-gray-800 text-hover-primary fw-bolder mb-3"><?=$userrow['name'];?></a>
                        <div class="badge badge-lg badge-light-primary d-inline mb-9">UID：<?=$userrow['uid'];?></div>
                        <div class="mb-7" style="width:100%">
													<!--begin::Item-->
													<div class="d-flex flex-stack">
														<div class="d-flex">
															<img src="static/picture/key-icon.svg" class="w-30px me-6" alt="">
															<div class="d-flex flex-column">
																<a href="JavaScript:;" class="fs-5 text-dark text-hover-primary fw-boldest">对接密钥</a>
																<div class="fs-8 fw-bold text-gray-400">KEY：{{row.key==0?'未开通':row.key}}</div>
															</div>
														</div>
														<div class="d-flex justify-content-end">
															<div class="form-check form-check-solid form-switch">
                                <button v-if="row.key!=0" type="submit" class="btn btn-light btn-sm" @click="ghapi">重置</button>
                                <button v-else type="submit" class="btn btn-light btn-sm" @click="ktapi">开通</button>
															</div>
														</div>
													</div>
													<!--end::Item-->
                          <div class="separator separator-dashed my-5"></div>
													<!--begin::Item-->
													<div class="d-flex flex-stack">
														<div class="d-flex">
															<img src="static/picture/price-icon.svg" class="w-30px me-6" alt="">
															<div class="d-flex flex-column">
																<a href="JavaScript:;" class="fs-5 text-dark text-hover-primary fw-boldest">下单折扣</a>
																<div class="fs-6 fw-bold text-gray-400">折扣：{{row.addprice}}</div>
															</div>
														</div>
														<div class="d-flex justify-content-end">
															<div class="form-check form-check-solid form-switch">
                                <button onclick="window.location.href='./myprice'" type="submit" class="btn btn-light btn-sm">查看</button>
															</div>
														</div>
													</div>
													<!--end::Item-->
													<div class="separator separator-dashed my-5"></div>
													<!--begin::Item-->
													<div class="d-flex flex-stack">
														<div class="d-flex">
															<img src="static/picture/share-icon.svg" class="w-30px me-6" alt="">
															<div class="d-flex flex-column">
																<a href="JavaScript:;" class="fs-5 text-dark text-hover-primary fw-boldest">邀请码</a>
																<div class="fs-6 fw-bold text-gray-400">码：{{row.yqm==''?'无':row.yqm}} / 折扣：{{row.yqprice==''?'无':row.yqprice}}</div>
															</div>
														</div>
														<div class="d-flex justify-content-end">
                              <button type="submit" data-bs-toggle="modal" data-bs-target="#modal_szyqprice" class="btn btn-light btn-sm">设置</button>
														</div>
													</div>
													<!--end::Item-->
												</div>
                      </div>
                      <!--end::Wrapper-->
                    </div>
                    <!--end::Body-->
                  </div>
                  <!--end::Engage Widget 1-->
                </div>
                <!--资料卡 - 结束-->
                <!-- 公告和账户 - 开始 -->
                <div class="col-xl-4">
                  <!--begin::Slider widget 2-->
                  <div class="card card-stretch-50 mb-5 mb-xxl-8">
                    <!--begin::Body-->
                    <div class="card-body p-9">
                      <div class="fs-2hx fw-boldest text-primary">&yen; {{row.money}}</div>
                      <div class="fs-4 fw-bold text-gray-400 mb-7">账户余额 / 总充值：&yen; {{row.zcz==null?'0':row.zcz}}</div>
                      <div class="fs-6 d-flex justify-content-between mb-4">
                        <div class="fw-bold">查课次数</div>
                        <div class="d-flex fw-boldest">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr007.svg-->
                        <span class="svg-icon svg-icon-3 me-1 svg-icon-success">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.4 10L5.3 18.1C4.9 18.5 4.9 19.1 5.3 19.5C5.7 19.9 6.29999 19.9 6.69999 19.5L14.8 11.4L13.4 10Z" fill="black"></path>
                            <path opacity="0.3" d="M19.8 16.3L8.5 5H18.8C19.4 5 19.8 5.4 19.8 6V16.3Z" fill="black"></path>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->{{row.ck}} 次</div>
                      </div>
                      <div class="separator separator-dashed"></div>
                      <div class="fs-6 d-flex justify-content-between my-4">
                        <div class="fw-bold">订单数量</div>
                        <div class="d-flex fw-boldest">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr006.svg-->
                        <span class="svg-icon svg-icon-3 me-1 svg-icon-success">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.4 10L5.3 18.1C4.9 18.5 4.9 19.1 5.3 19.5C5.7 19.9 6.29999 19.9 6.69999 19.5L14.8 11.4L13.4 10Z" fill="black"></path>
                            <path opacity="0.3" d="M19.8 16.3L8.5 5H18.8C19.4 5 19.8 5.4 19.8 6V16.3Z" fill="black"></path>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->{{row.dd}} 单</div>
                      </div>
                      <div class="separator separator-dashed"></div>
                      <div class="fs-6 d-flex justify-content-between mt-4 mb-5">
                        <div class="fw-bold">下单比率</div>
                        <div class="d-flex fw-boldest">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr007.svg-->
                        <span class="svg-icon svg-icon-3 me-1 svg-icon-danger">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M13.4 14.8L5.3 6.69999C4.9 6.29999 4.9 5.7 5.3 5.3C5.7 4.9 6.29999 4.9 6.69999 5.3L14.8 13.4L13.4 14.8Z" fill="black"></path>
                            <path opacity="0.3" d="M19.8 8.5L8.5 19.8H18.8C19.4 19.8 19.8 19.4 19.8 18.8V8.5Z" fill="black"></path>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->{{row.lv}} %</div>
                      </div>
                    </div>
                    <!--end::Body-->
                  </div>
                  <!--end::Slider widget 2-->
                  <!--begin::Slider Widget 1-->
                  <div class="card card-stretch-50 mb-5 mb-xxl-8">
                    <!--begin::Body-->
                    <div class="card-body pt-5">
                      <div id="kt_stats_widget_8_carousel" class="carousel carousel-custom carousel-stretch slide" data-bs-ride="carousel" data-bs-interval="8000">
                        <!--begin::Heading-->
                        <div class="d-flex flex-stack flex-wrap">
                          <span class="fs-4 text-gray-400 fw-boldest pe-2">待办事件</span>
                          <!--begin::Carousel Indicators-->
                          <ol class="p-0 m-0 carousel-indicators carousel-indicators-dots">
                            <li data-bs-target="#kt_stats_widget_8_carousel" data-bs-slide-to="0" class="ms-1 active" aria-current="true"></li>
                            <li data-bs-target="#kt_stats_widget_8_carousel" data-bs-slide-to="1" class="ms-1"></li>
                            <li data-bs-target="#kt_stats_widget_8_carousel" data-bs-slide-to="2" class="ms-1"></li>
                            <li data-bs-target="#kt_stats_widget_8_carousel" data-bs-slide-to="3" class="ms-1"></li>
                          </ol>
                          <!--end::Carousel Indicators-->
                        </div>
                        <!--end::Heading-->
                        <!--begin::Carousel-->
                        <div class="carousel-inner pt-6">
                          <!--begin::Item-->
                          <div class="carousel-item active">
                            <div class="carousel-wrapper">
                              <div class="d-flex flex-column justify-content-center flex-grow-1">
                                <a href="" class="fs-2 text-gray-800 text-hover-primary fw-boldest">活动名称</a>
                                <p class="text-gray-600 fs-6 fw-bold pt-4 mb-0 ellipsis">活动具体内容活动具体内容活动具体内容活动具体内容活动具体内容活动具体内容活动具体内容活动具体内容活动具体内容活动具体内容</p>
                              </div>
                              <!--begin::Info-->
                              <div class="d-flex flex-stack pt-8">
                                <span class="badge badge-light-primary fs-7 fw-boldest me-2"><?php echo date("Y-m-d"); ?></span>
                                <a href="JavaScript:;" class="btn btn-light btn-sm btn-color-muted fs-7 fw-boldest px-5" data-bs-toggle="modal" data-bs-target="#kt_modal_upgrade_plan">查看详情</a>
                              </div>
                              <!--end::Info-->
                            </div>
                          </div>
                          <!--end::Item-->
                          <!--begin::Item-->
                          <div class="carousel-item">
                            <div class="carousel-wrapper">
                              <!--begin::Title-->
                              <div class="d-flex flex-column justify-content-center flex-grow-1">
                                <a href="" class="fs-2 text-gray-800 text-hover-primary fw-boldest">活动名称</a>
                                <p class="text-gray-600 fs-6 fw-bold pt-4 mb-0">活动具体内容活动具体内容活动具体内容活动具体内容活动具体内容</p>
                              </div>
                              <!--end::Title-->
                              <!--begin::Info-->
                              <div class="d-flex flex-stack pt-8">
                                <span class="badge badge-light-primary fs-7 fw-boldest me-2"><?php echo date("Y-m-d"); ?></span>
                                <a href="JavaScript:;" class="btn btn-light btn-sm btn-color-muted fs-7 fw-boldest px-5" data-bs-toggle="modal" data-bs-target="#kt_modal_upgrade_plan">查看详情</a>
                              </div>
                              <!--end::Info-->
                            </div>
                          </div>
                          <!--end::Item-->
                          <!--begin::Item-->
                          <div class="carousel-item">
                            <div class="carousel-wrapper">
                              <!--begin::Title-->
                              <div class="d-flex flex-column justify-content-center flex-grow-1">
                                <a href="" class="fs-2 text-gray-800 text-hover-primary fw-boldest">活动名称</a>
                                <p class="text-gray-600 fs-6 fw-bold pt-4 mb-0">活动具体内容活动具体内容活动具体内容活动具体内容活动具体内容</p>
                              </div>
                              <!--end::Title-->
                              <!--begin::Info-->
                              <div class="d-flex flex-stack pt-8">
                                <span class="badge badge-light-primary fs-7 fw-boldest me-2"><?php echo date("Y-m-d"); ?></span>
                                <a href="JavaScript:;" class="btn btn-light btn-sm btn-color-muted fs-7 fw-boldest px-5" data-bs-toggle="modal" data-bs-target="#kt_modal_upgrade_plan">查看详情</a>
                              </div>
                              <!--end::Info-->
                            </div>
                          </div>
                          <!--end::Item-->
                          <!--begin::Item-->
                          <div class="carousel-item">
                            <div class="carousel-wrapper">
                              <!--begin::Title-->
                              <div class="d-flex flex-column justify-content-center flex-grow-1">
                                <a href="" class="fs-2 text-gray-800 text-hover-primary fw-boldest">活动名称</a>
                                <p class="text-gray-600 fs-6 fw-bold pt-4 mb-0">活动具体内容活动具体内容活动具体内容活动具体内容活动具体内容</p>
                              </div>
                              <!--end::Title-->
                              <!--begin::Info-->
                              <div class="d-flex flex-stack pt-8">
                                <span class="badge badge-light-primary fs-7 fw-boldest me-2"><?php echo date("Y-m-d"); ?></span>
                                <a href="JavaScript:;" class="btn btn-light btn-sm btn-color-muted fs-7 fw-boldest px-5" data-bs-toggle="modal" data-bs-target="#kt_modal_upgrade_plan">查看详情</a>
                              </div>
                              <!--end::Info-->
                            </div>
                          </div>
                          <!--end::Item-->
                        </div>
                        <!--end::Carousel-->
                      </div>
                    </div>
                    <!--end::Body-->
                  </div>
                  <!--end::Slider Widget 1-->
                </div>
                <!-- 公告和账户 - 结束 -->
                <!--begin::Col-->
                <div class="col-xxl-4">
                  <!--begin::Chart Widget 4-->
                  <div class="card card-xl-stretch mb-5 mb-xl-8">
                    <!--begin::Beader-->
                    <div class="card-header border-0 py-5">
                      <h3 class="card-title align-items-start flex-column">
                        <span class="card-label fw-boldest text-dark fs-2">功能开通</span>
                        <span class="text-gray-400 mt-2 fw-bold fs-6">请您按自己的需求开通功能</span>
                      </h3>
                      <div class="card-toolbar">
                        <!--begin::Menu-->
                        <button type="button" class="btn btn-clean btn-sm btn-icon btn-icon-primary btn-active-light-primary me-n3" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                          <!--begin::Svg Icon | path: icons/duotune/general/gen024.svg-->
                          <span class="svg-icon svg-icon-3 svg-icon-primary">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewbox="0 0 24 24">
                              <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <rect x="5" y="5" width="5" height="5" rx="1" fill="#000000"></rect>
                                <rect x="14" y="5" width="5" height="5" rx="1" fill="#000000" opacity="0.3"></rect>
                                <rect x="5" y="14" width="5" height="5" rx="1" fill="#000000" opacity="0.3"></rect>
                                <rect x="14" y="14" width="5" height="5" rx="1" fill="#000000" opacity="0.3"></rect>
                              </g>
                            </svg>
                          </span>
                          <!--end::Svg Icon-->
                        </button>
                        <!--begin::Menu 2-->
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg-light-primary fw-bold w-200px" data-kt-menu="true">
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <div class="menu-content fs-6 text-dark fw-bolder px-3 py-4">快捷菜单</div>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu separator-->
                          <div class="separator mb-3 opacity-75"></div>
                          <!--end::Menu separator-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3">快捷登录</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3">
                            <a href="JavaScript:;" class="menu-link px-3">对接密钥</a>
                          </div>
                          <!--end::Menu item-->
                          <!--begin::Menu item-->
                          <div class="menu-item px-3 mb-5">
                            <a href="JavaScript:;" class="menu-link px-3">设置邀请码</a>
                          </div>
                          <!--end::Menu item-->
                        </div>
                        <!--end::Menu 2-->
                        <!--end::Menu-->
                      </div>
                    </div>
                    <!--end::Header-->
                    <!--begin::Body-->
                    <div class="card-body d-flex flex-column pt-0">
                      <!--begin::Chart-->
                      <div class="d-flex flex-center position-relative">
                        <div id="chart-renwu" style="height: 250px;width: 100%"></div>
                      </div>
                      <!--end::Chart-->
                      <!--begin::Items-->
                      <div class="mt-n20 pb-5 position-relative zindex-1">
                        <!--begin::Item-->
                        <div class="d-flex flex-stack mb-6">
                          <!--begin::Section-->
                          <div class="d-flex align-items-center me-2">
                            <!--begin::Symbol-->
                            <div class="symbol symbol-45px me-5">
                              <span class="symbol-label bg-light-success">
                                <!--begin::Svg Icon | path: /icons/duotune/maps/map004.svg-->
                                <span class="svg-icon svg-icon-2 svg-icon-success">
                                  <svg t="1678535103130" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3613" width="200" height="200"><path d="M116.435 593.714c-33.54 78.964-38.985 154.297-12.059 168.37 18.572 9.696 47.686-12.382 74.936-52.909 10.791 44.157 37.493 84.137 75.633 116.21-40.004 14.768-66.135 38.886-66.135 66.232 0 44.954 70.709 81.302 157.978 81.302 78.716 0 143.907-29.538 155.94-68.371 3.232-0.049 15.663-0.049 18.796 0 12.083 38.784 77.324 68.371 155.989 68.371 87.267 0 157.978-36.398 157.978-81.302 0-27.297-26.105-51.464-66.135-66.232 38.089-32.123 64.889-72.053 75.631-116.21 27.251 40.527 56.29 62.605 74.887 52.909 26.95-14.073 21.631-89.456-12.032-168.37-26.355-62.058-62.11-107.754-89.457-117.848 0.398-3.929 0.596-7.958 0.596-11.935 0-23.968-6.661-46.146-18.049-64.196 0.199-1.393 0.199-2.834 0.199-4.227 0-11.038-2.636-21.381-7.114-30.332-6.909-161.309-111.93-289.402-281.866-289.402-170.036 0-275.106 128.093-281.943 289.402-4.525 9.001-7.135 19.343-7.135 30.332 0 1.393 0.099 2.835 0.15 4.227-11.288 18.05-17.951 40.178-17.951 64.196 0 3.978 0.15 7.955 0.498 11.935-27.151 10.094-63.028 55.841-89.333 117.848z" fill="#272636" p-id="3614"></path></svg>
                                </span>
                                <!--end::Svg Icon-->
                              </span>
                            </div>
                            <!--end::Symbol-->
                            <!--begin::Title-->
                            <div>
                              <a href="javascript:;" class="fs-5 text-gray-800 text-hover-primary fw-boldest">快捷登录</a>
                              <div class="fs-7 text-gray-400 fw-bold mt-1">绑定QQ快捷登录</div>
                            </div>
                            <!--end::Title-->
                          </div>
                          <!--end::Section-->
                          <!--begin::Action-->
                          <?php if($userrow['qq_openid']==''){ ?>
                          <a href="javascript:;" @click="connect_qq" class="btn btn-icon btn-light btn-sm">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
                            <span class="svg-icon svg-icon-4 svg-icon-gray-400">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                                <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                              </svg>
                            </span>
                            <!--end::Svg Icon-->
                          </a>
                          <?php } else { ?>
                          <button class="btn btn-icon btn-light btn-primary btn-sm">
                            <span class="svg-icon svg-icon-2 d-none">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.5" d="M18 2H9C7.34315 2 6 3.34315 6 5H8C8 4.44772 8.44772 4 9 4H18C18.5523 4 19 4.44772 19 5V16C19 16.5523 18.5523 17 18 17V19C19.6569 19 21 17.6569 21 16V5C21 3.34315 19.6569 2 18 2Z" fill="black"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M14.7857 7.125H6.21429C5.62255 7.125 5.14286 7.6007 5.14286 8.1875V18.8125C5.14286 19.3993 5.62255 19.875 6.21429 19.875H14.7857C15.3774 19.875 15.8571 19.3993 15.8571 18.8125V8.1875C15.8571 7.6007 15.3774 7.125 14.7857 7.125ZM6.21429 5C4.43908 5 3 6.42709 3 8.1875V18.8125C3 20.5729 4.43909 22 6.21429 22H14.7857C16.5609 22 18 20.5729 18 18.8125V8.1875C18 6.42709 16.5609 5 14.7857 5H6.21429Z" fill="black"></path>
                              </svg>
                            </span>
                            <i class="bi bi-check fs-2x"></i>
                          </button>
                          <?php } ?>
                          <!--end::Action-->
                        </div>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <div class="d-flex flex-stack mb-6">
                          <!--begin::Section-->
                          <div class="d-flex align-items-center me-2">
                            <!--begin::Symbol-->
                            <div class="symbol symbol-45px me-5">
                              <span class="symbol-label bg-light-danger">
                                <!--begin::Svg Icon | path: icons/duotune/general/gen025.svg-->
                                <span class="svg-icon svg-icon-2 svg-icon-danger">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path opacity="0.3" d="M18.4 5.59998C18.7766 5.9772 18.9881 6.48846 18.9881 7.02148C18.9881 7.55451 18.7766 8.06577 18.4 8.44299L14.843 12C14.466 12.377 13.9547 12.5887 13.4215 12.5887C12.8883 12.5887 12.377 12.377 12 12C11.623 11.623 11.4112 11.1117 11.4112 10.5785C11.4112 10.0453 11.623 9.53399 12 9.15698L15.553 5.604C15.9302 5.22741 16.4415 5.01587 16.9745 5.01587C17.5075 5.01587 18.0188 5.22741 18.396 5.604L18.4 5.59998ZM20.528 3.47205C20.0614 3.00535 19.5074 2.63503 18.8977 2.38245C18.288 2.12987 17.6344 1.99988 16.9745 1.99988C16.3145 1.99988 15.661 2.12987 15.0513 2.38245C14.4416 2.63503 13.8876 3.00535 13.421 3.47205L9.86801 7.02502C9.40136 7.49168 9.03118 8.04568 8.77863 8.6554C8.52608 9.26511 8.39609 9.91855 8.39609 10.5785C8.39609 11.2384 8.52608 11.8919 8.77863 12.5016C9.03118 13.1113 9.40136 13.6653 9.86801 14.132C10.3347 14.5986 10.8886 14.9688 11.4984 15.2213C12.1081 15.4739 12.7616 15.6039 13.4215 15.6039C14.0815 15.6039 14.7349 15.4739 15.3446 15.2213C15.9543 14.9688 16.5084 14.5986 16.975 14.132L20.528 10.579C20.9947 10.1124 21.3649 9.55844 21.6175 8.94873C21.8701 8.33902 22.0001 7.68547 22.0001 7.02551C22.0001 6.36555 21.8701 5.71201 21.6175 5.10229C21.3649 4.49258 20.9947 3.93867 20.528 3.47205Z" fill="currentColor"/>
                                  <path d="M14.132 9.86804C13.6421 9.37931 13.0561 8.99749 12.411 8.74695L12 9.15698C11.6234 9.53421 11.4119 10.0455 11.4119 10.5785C11.4119 11.1115 11.6234 11.6228 12 12C12.3766 12.3772 12.5881 12.8885 12.5881 13.4215C12.5881 13.9545 12.3766 14.4658 12 14.843L8.44699 18.396C8.06999 18.773 7.55868 18.9849 7.02551 18.9849C6.49235 18.9849 5.98101 18.773 5.604 18.396C5.227 18.019 5.0152 17.5077 5.0152 16.9745C5.0152 16.4413 5.227 15.93 5.604 15.553L8.74701 12.411C8.28705 11.233 8.28705 9.92498 8.74701 8.74695C8.10159 8.99737 7.5152 9.37919 7.02499 9.86804L3.47198 13.421C2.52954 14.3635 2.00009 15.6417 2.00009 16.9745C2.00009 18.3073 2.52957 19.5855 3.47202 20.528C4.41446 21.4704 5.69269 21.9999 7.02551 21.9999C8.35833 21.9999 9.63656 21.4704 10.579 20.528L14.132 16.975C14.5987 16.5084 14.9689 15.9544 15.2215 15.3447C15.4741 14.735 15.6041 14.0815 15.6041 13.4215C15.6041 12.7615 15.4741 12.108 15.2215 11.4983C14.9689 10.8886 14.5987 10.3347 14.132 9.86804Z" fill="currentColor"/>
                                </svg>
                                </span>
                                <!--end::Svg Icon-->
                              </span>
                            </div>
                            <!--end::Symbol-->
                            <!--begin::Title-->
                            <div>
                              <a href="javascript:;" class="fs-5 text-gray-800 text-hover-primary fw-boldest">对接密钥</a>
                              <div class="fs-7 text-gray-400 fw-bold mt-1">开启产品对接密钥</div>
                            </div>
                            <!--end::Title-->
                          </div>
                          <!--end::Section-->
                          <!--begin::Action-->
                          <?php if($userrow['key']=='0'){ ?>
                          <a href="javascript:;" @click="ktapi" class="btn btn-icon btn-light btn-sm">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
                            <span class="svg-icon svg-icon-4 svg-icon-gray-400">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                                <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                              </svg>
                            </span>
                            <!--end::Svg Icon-->
                          </a>
                          <?php } else { ?>
                          <button class="btn btn-icon btn-light btn-primary btn-sm">
                            <span class="svg-icon svg-icon-2 d-none">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.5" d="M18 2H9C7.34315 2 6 3.34315 6 5H8C8 4.44772 8.44772 4 9 4H18C18.5523 4 19 4.44772 19 5V16C19 16.5523 18.5523 17 18 17V19C19.6569 19 21 17.6569 21 16V5C21 3.34315 19.6569 2 18 2Z" fill="black"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M14.7857 7.125H6.21429C5.62255 7.125 5.14286 7.6007 5.14286 8.1875V18.8125C5.14286 19.3993 5.62255 19.875 6.21429 19.875H14.7857C15.3774 19.875 15.8571 19.3993 15.8571 18.8125V8.1875C15.8571 7.6007 15.3774 7.125 14.7857 7.125ZM6.21429 5C4.43908 5 3 6.42709 3 8.1875V18.8125C3 20.5729 4.43909 22 6.21429 22H14.7857C16.5609 22 18 20.5729 18 18.8125V8.1875C18 6.42709 16.5609 5 14.7857 5H6.21429Z" fill="black"></path>
                              </svg>
                            </span>
                            <i class="bi bi-check fs-2x"></i>
                          </button>
                          <?php } ?>
                          <!--end::Action-->
                        </div>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <div class="d-flex flex-stack mb-">
                          <!--begin::Section-->
                          <div class="d-flex align-items-center me-2">
                            <!--begin::Symbol-->
                            <div class="symbol symbol-45px me-5">
                              <span class="symbol-label bg-light-info">
                                <!--begin::Svg Icon | path: icons/duotune/abstract/abs019.svg-->
                                <span class="svg-icon svg-icon-2 svg-icon-info">
                                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M21 9V11C21 11.6 20.6 12 20 12H14V8H20C20.6 8 21 8.4 21 9ZM10 8H4C3.4 8 3 8.4 3 9V11C3 11.6 3.4 12 4 12H10V8Z" fill="currentColor"/>
                                    <path d="M15 2C13.3 2 12 3.3 12 5V8H15C16.7 8 18 6.7 18 5C18 3.3 16.7 2 15 2Z" fill="currentColor"/>
                                    <path opacity="0.3" d="M9 2C10.7 2 12 3.3 12 5V8H9C7.3 8 6 6.7 6 5C6 3.3 7.3 2 9 2ZM4 12V21C4 21.6 4.4 22 5 22H10V12H4ZM20 12V21C20 21.6 19.6 22 19 22H14V12H20Z" fill="currentColor"/>
                                  </svg>
                                </span>
                                <!--end::Svg Icon-->
                              </span>
                            </div>
                            <!--end::Symbol-->
                            <!--begin::Title-->
                            <div>
                              <a href="javascript:;" class="fs-5 text-gray-800 text-hover-primary fw-boldest">设置邀请码</a>
                              <div class="fs-7 text-gray-400 fw-bold mt-1">用户可通过邀请码进行注册</div>
                            </div>
                            <!--end::Title-->
                          </div>
                          <!--end::Section-->
                          <!--begin::Action-->
                          <?php if($userrow['yqm']==''){ ?>
                          <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#modal_szyqprice" class="btn btn-icon btn-light btn-sm">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr064.svg-->
                            <span class="svg-icon svg-icon-4 svg-icon-gray-400">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                <rect opacity="0.5" x="18" y="13" width="13" height="2" rx="1" transform="rotate(-180 18 13)" fill="black"></rect>
                                <path d="M15.4343 12.5657L11.25 16.75C10.8358 17.1642 10.8358 17.8358 11.25 18.25C11.6642 18.6642 12.3358 18.6642 12.75 18.25L18.2929 12.7071C18.6834 12.3166 18.6834 11.6834 18.2929 11.2929L12.75 5.75C12.3358 5.33579 11.6642 5.33579 11.25 5.75C10.8358 6.16421 10.8358 6.83579 11.25 7.25L15.4343 11.4343C15.7467 11.7467 15.7467 12.2533 15.4343 12.5657Z" fill="black"></path>
                              </svg>
                            </span>
                            <!--end::Svg Icon-->
                          </a>
                          <?php } else { ?>
                          <button class="btn btn-icon btn-light btn-primary btn-sm">
                            <span class="svg-icon svg-icon-2 d-none">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.5" d="M18 2H9C7.34315 2 6 3.34315 6 5H8C8 4.44772 8.44772 4 9 4H18C18.5523 4 19 4.44772 19 5V16C19 16.5523 18.5523 17 18 17V19C19.6569 19 21 17.6569 21 16V5C21 3.34315 19.6569 2 18 2Z" fill="black"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M14.7857 7.125H6.21429C5.62255 7.125 5.14286 7.6007 5.14286 8.1875V18.8125C5.14286 19.3993 5.62255 19.875 6.21429 19.875H14.7857C15.3774 19.875 15.8571 19.3993 15.8571 18.8125V8.1875C15.8571 7.6007 15.3774 7.125 14.7857 7.125ZM6.21429 5C4.43908 5 3 6.42709 3 8.1875V18.8125C3 20.5729 4.43909 22 6.21429 22H14.7857C16.5609 22 18 20.5729 18 18.8125V8.1875C18 6.42709 16.5609 5 14.7857 5H6.21429Z" fill="black"></path>
                              </svg>
                            </span>
                            <i class="bi bi-check fs-2x"></i>
                          </button>
                          <?php } ?>
                          <!--end::Action-->
                        </div>
                        <!--end::Item-->
                      </div>
                      <!--end::Items-->
                    </div>
                    <!--end::Body-->
                  </div>
                  <!--end::Chart Widget 4-->
                </div>
                <!--end::Col-->
              </div>
              <!--end::Row-->
              <!-- 修改费率弹窗 - 开始 -->
              <div class="modal fade" id="modal_szyqprice" tabindex="-1" aria-hidden="true">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                  <!--begin::Modal content-->
                  <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                      <!--begin::Modal title-->
                      <h3 class="fw-boldest text-dark fs-1 mb-0">设置邀请费率</h3>
                      <!--end::Modal title-->
                      <!--begin::Close-->
                      <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-2x">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)"
                              fill="black"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black">
                            </rect>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                      </div>
                      <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                      <!--begin::Form-->
                      <form class="form" action="#" @submit.prevent="">
                        <!--begin::Input group-->
                        <div class="d-flex flex-column mb-7 fv-row">
                          <input v-model="yqprice" type="text" class="form-control form-control-solid" placeholder="请输入邀请费率" autocomplete="off" />
                        </div>
                        <div class="text-gray-600">设置下级默认费率，首次自动生成邀请码</div>
                        <!--end::Input group-->
                        <!--begin::Actions-->
                        <div class="text-center pt-15">
                          <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">取消</button>
                          <button id="yqPriceSubmitBtn" type="button" class="btn btn-primary" @click="szyqprice"><span
                              class="indicator-label">确认提交</span>
                            <span class="indicator-progress">Please wait...
                              <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span></button>
                        </div>
                        <!--end::Actions-->
                      </form>
                      <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                  </div>
                  <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
              </div>
              <!-- 修改费率弹窗 - 结束 -->
            </div>
            <!--end::Container-->
          </div>
          <!--end::Post-->
        </div>
        <!--页面主内容 - 结束-->
        <!--页面底部 - 开始-->
        <?php include('./footer.php'); ?>
        <!--页面底部 - 结束-->
      </div>
      <!--end::Wrapper-->
    </div>
    <!--end::Page-->
  </div>
  <!--end::Root-->
  <!-- 底部 - 开始 -->
  <?php require_once('./foot.php'); ?>
  <!-- 底部 - 结束 -->
  <!-- 本页面需要 - 开始 -->
  <script src="https://lib.baomitu.com/echarts/5.3.2-rc.1/echarts.common.js"></script>
  <script src="static/main/pages/home.js"></script>
  <!-- 本页面需要 - 结束 -->
</body>
<!--end::Body-->

</html>