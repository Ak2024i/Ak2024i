<?php
include('../confing/common.php');
if($islogin!=1){exit("<script language='javascript'>window.location.href='login';</script>");  }
?>

<head>
  <title>
    <?php echo $pagename ?> –
    <?=$conf['sitename']?>
  </title>
  <meta charset="utf-8" />
  <meta name="keywords" content="<?=$conf['keywords'];?>" />
  <meta name="description" content="<?=$conf['description'];?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="shortcut icon" href="static/picture/logo.png" />
  <!--begin::Fonts-->
  <link rel="stylesheet" href="static/css/css.css" />
  <!--end::Fonts-->
  <link href="static/css/element.css" rel="stylesheet" type="text/css" />
  <link href="static/css/plugins.bundle.css" rel="stylesheet" type="text/css" />
  <link href="static/css/style.bundle.css" rel="stylesheet" type="text/css" />
  <!-- <script src="static/main/unc.js"></script> -->
</head>
<?php if($userrow['active']=="0"){alert('您的账号已被封禁！','login');} ?>