<!DOCTYPE html>
<html lang="zh">
<?php $pagename="操作日志" ?>
<!-- 头部 - 开始 -->
<?php require_once('./head.php'); ?>
<!-- 头部 - 结束 -->

<!--begin::Body-->

<body id="kt_body"
  class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled aside-fixed aside-default-enabled">

  <!--begin::Root-->
  <div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="page d-flex flex-row flex-column-fluid">
      <!--侧边栏 - 开始-->
      <?php include('./aside.php'); ?>
      <!--侧边栏 - 结束-->
      <!--begin::Wrapper-->
      <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
        <!--页面头部 - 开始-->
        <?php include('./header.php'); ?>
        <!--页面头部 - 结束-->
        <!--页面主内容 - 开始-->
        <div class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
          <!--begin::Toolbar-->
          <div class="toolbar" id="kt_toolbar">
            <div class="container-fluid d-flex flex-stack flex-wrap flex-sm-nowrap">
              <!--begin::Info-->
              <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                <!--begin::Title-->
                <h1 class="text-dark fw-bolder my-1 fs-2"><?php echo $pagename ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb fw-bold fs-base my-1">
                  <li class="breadcrumb-item text-muted">
                    <a href="./index" class="text-muted text-hover-primary">首页</a>
                  </li>
                  <li class="breadcrumb-item text-muted">用户中心</li>
                  <li class="breadcrumb-item text-dark"><?php echo $pagename ?></li>
                </ul>
                <!--end::Breadcrumb-->
              </div>
              <!--end::Info-->
              <!--begin::Actions-->
              <div class="d-flex align-items-center flex-nowrap text-nowrap py-1">
                <a href="JavaScript:;" class="btn bg-body btn-color-gray-700 btn-active-primary me-4" data-bs-toggle="modal" data-bs-target="#modal_usernotice">站点公告</a>
                <a href="JavaScript:;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_tcgonggao">重要通知</a>
              </div>
              <!--end::Actions-->
            </div>
          </div>
          <!--end::Toolbar-->
          <!--begin::Post-->
          <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div id="log" class="container-xxl">
              <!--begin::Card-->
              <div class="card card-flush">
                <!--begin::Card header-->
                <div class="card-header mt-6">
                  <!--begin::Card title-->
                  <div class="card-title">
                    <!--begin::Select-->
                    <div class="me-6 my-1">
                      <select v-model="type" data-hide-search="true" class="w-125px form-select form-select-solid">
                        <option value="" selected="selected">所有</option>
				                <option value="登录">登录</option>
				                <option value="添加任务">添加任务</option>
				                <option value="批量提交">批量提交</option>
				                <option value="API添加任务">API添加任务</option>
				                <option value="上级充值">上级充值</option>
				                <option value="代理充值">代理充值</option>
				                <option value="修改费率">修改费率</option>
				                <option value="查课">查课</option>
				                <option value="API查课">API查课</option>
				                <option value="在线充值">在线充值</option>
				                <option value="订单退款">订单退款</option>
                      </select>
                    </div>
                    <!--end::Select-->
                    <!--begin::Select-->
                    <!-- <div class="me-4 my-1">
                      <select v-model="types" data-hide-search="true" class="w-125px form-select form-select-solid">
                        <option value="" selected="selected">所有</option>
				                <option value="1">用户名</option>
				                <option value="2">余额变动</option>
				                <option value="3">时间</option>
                      </select>
                    </div> -->
                    <!--end::Select-->
                    <!--begin::Search-->
                    <div class="d-flex align-items-center position-relative my-1 me-5">
                      <!--begin::Svg Icon | path: icons/duotune/general/gen021.svg-->
                      <span class="svg-icon svg-icon-1 position-absolute ms-6">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                          <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="black"></rect>
                          <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="black"></path>
                        </svg>
                      </span>
                      <!--end::Svg Icon-->
                      <input type="text" v-model="qq" data-kt-permissions-table-filter="search" class="form-control form-control-solid w-250px ps-15" placeholder="Search...">
                    </div>
                    <!--end::Search-->
                    <!--begin::Action-->
                    <button type="button" @click="get(1,1)" class="btn btn-primary btn-icon flex-shrink-0">
                      <!--begin::Svg Icon | path: icons/duotune/arrows/arr065.svg-->
                      <span class="svg-icon svg-icon-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                          <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="black"></rect>
                          <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="black"></path>
                        </svg>
                      </span>
                      <!--end::Svg Icon-->
                    </button>
                    <!--end::Action-->
                  </div>
                  <!--end::Card title-->
                </div>
                <!--end::Card header-->
                <!--begin::Card body-->
                <div v-if="logList == null" class="card-body pt-0">
                  <div class="text-center px-5">
                    <img src="static/picture/20.png" alt="" class="mw-100 mh-325px">
                    <h1 class="fw-bold mt-5" style="color: #A3A3C7">暂无数据</h1>
                  </div>
                </div>
                <div v-else class="card-body pt-0">
                  <div class="table-responsive">
                    <!--begin::Table-->
                    <table class="table align-middle table-row-dashed fs-6 gy-5 mb-0">
                      <!--begin::Table head-->
                      <thead>
                        <!--begin::Table row-->
                        <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                          <th class="min-w-50px">ID</th>
                          <th class="min-w-50px">操作者ID</th>
                          <th class="min-w-100px">操作类型</th>
                          <th class="min-w-50px">变动金额</th>
                          <th class="min-w-80px">账户余额</th>
                          <th class="min-w-150px">操作内容</th>
                          <th class="min-w-80px">操作时间</th>
                        </tr>
                        <!--end::Table row-->
                      </thead>
                      <!--end::Table head-->
                      <!--begin::Table body-->
                      <tbody class="fw-bold text-gray-600">
                        <tr v-for="res in row.data" :key="res.id">
                          <td>{{res.id}}</td>
                          <td>{{res.uid}}</td>
                          <td><span class="badge badge-light-danger" v-if="res.type=='批量提交' ||res.type=='添加任务' || res.type=='API添加任务'">{{res.type}}</span><span class="badge badge-light-warning" v-else-if="res.type=='代理充值'">代理充值</span><span class="badge badge-light-success" v-else-if="res.type=='上级充值'">上级充值</span><span class="badge badge-light-info" v-else-if="res.type=='添加商户'">添加商户</span><span class="badge badge-light-dark" v-else-if="res.type=='修改费率'">修改费率</span><span class="badge badge-light-primary" v-else="">{{res.type}}</span></td>
                          <td>{{res.money}}</td>
                          <td>{{res.smoney}}</td>
                          <td>{{res.text}}</td>
                          <td>{{res.addtime}}</td>
                        </tr>
                      </tbody>
                      <!--end::Table body-->
                    </table>
                    <!--end::Table-->
                  </div>
                  <!-- 分页 - 开始 -->
                  <?php include('./pagination.php'); ?>
                  <!-- 分页 - 结束 -->
                </div>
                <!--end::Card body-->
              </div>
              <!--end::Card-->
            </div>
            <!--end::Container-->
          </div>
          <!--end::Post-->
        </div>
        <!--页面主内容 - 结束-->
        <!--页面底部 - 开始-->
        <?php include('./footer.php'); ?>
        <!--页面底部 - 结束-->
      </div>
      <!--end::Wrapper-->
    </div>
    <!--end::Page-->
  </div>
  <!--end::Root-->
  <!-- 底部 - 开始 -->
  <?php require_once('./foot.php'); ?>
  <!-- 底部 - 结束 -->
  <!-- 本页面需要 - 开始 -->
  <script src="static/main/pages/log.js"></script>
  <!-- 本页面需要 - 结束 -->
</body>
<!--end::Body-->

</html>