<?php
include('../confing/common.php');
?>
<!DOCTYPE html>
<html lang="zh">
<!--begin::Head-->

<head>
  <title>用户注册 – <?=$conf['sitename']?></title>
  <meta charset="utf-8">
  <meta name="description" content="<?=$conf['description'];?>" />
  <meta name="keywords" content="<?=$conf['keywords'];?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="<?=$conf['logo'];?>">
  <!--begin::Fonts-->
  <link rel="stylesheet" href="static/css/css.css">
  <!--end::Fonts-->
  <!--begin::Global Stylesheets Bundle(used by all pages)-->
  <link href="static/css/plugins.bundle.css" rel="stylesheet" type="text/css">
  <link href="static/css/style.bundle.css" rel="stylesheet" type="text/css">
  <script src="static/main/unc.js"></script>
  <!--end::Global Stylesheets Bundle-->
</head>
<!--end::Head-->
<!--begin::Body-->

<body id="kt_body" class="auth-bg">
  <!--begin::Main-->
  <div id="register" class="d-flex flex-column flex-root">
    <!--begin::Authentication - Sign-up -->
    <div class="d-flex flex-column flex-lg-row flex-column-fluid">
      <!--begin::Aside-->
      <div class="d-flex flex-column flex-lg-row-auto bg-primary w-xl-600px positon-xl-relative">
        <!--begin::Wrapper-->
        <div class="d-flex flex-column position-xl-fixed top-0 bottom-0 w-xl-600px scroll-y">
          <!--begin::Header-->
          <div class="d-flex flex-row-fluid flex-column text-center p-10 pt-lg-20">
            <!--begin::Logo-->
            <a href="javascript:;" class="py-9 pt-lg-20">
              <img alt="Logo" src="static/picture/logo-ellipse.svg" class="h-70px">
            </a>
            <!--end::Logo-->
            <!--begin::Title-->
            <h1 class="fw-bolder text-white fs-2qx pb-5 pb-md-10">欢迎使用爱学习</h1>
            <!--end::Title-->
            <!--begin::Description-->
            <p class="fw-bold fs-2 text-white">Plan your blog post by choosing a topic creating
              <br>an outline and checking facts
            </p>
            <!--end::Description-->
          </div>
          <!--end::Header-->
          <!--begin::Illustration-->
          <div
            class="d-flex flex-row-auto bgi-no-repeat bgi-position-x-center bgi-size-contain bgi-position-y-bottom min-h-100px min-h-lg-350px"
            style="background-image: url(static/image/17.png)"></div>
          <!--end::Illustration-->
        </div>
        <!--end::Wrapper-->
      </div>
      <!--begin::Aside-->
      <!--begin::Body-->
      <div class="d-flex flex-column flex-lg-row-fluid py-10">
        <!--begin::Content-->
        <div class="d-flex flex-center flex-column flex-column-fluid">
          <!--begin::Wrapper-->
          <div class="w-lg-600px p-10 p-lg-15 mx-auto">
            <!--begin::Form-->
            <form class="form w-100" novalidate="novalidate" id="kt_sign_up_form">
              <!--begin::Heading-->
              <div class="mb-10 text-center">
                <!--begin::Title-->
                <h1 class="text-dark mb-3">用户注册</h1>
                <!--end::Title-->
                <!--begin::Link-->
                <div class="text-gray-400 fw-bold fs-4">已有帐户?
                  <a href="./login" class="link-primary fw-bolder">点击登录</a>
                </div>
                <!--end::Link-->
              </div>
              <!--end::Heading-->
              <?php if($conf['login_kg']==1){ ?>
              <!--begin::Action-->
              <button id="connect_qq" type="button" class="btn btn-light-primary fw-bolder w-100 mb-10">
                <img alt="Logo" style="height: 24px!important;" src="static/picture/qq-icon.svg"
                  class="h-20px me-3">使用快捷登录</button>
              <!--end::Action-->
              <!--begin::Separator-->
              <div class="d-flex align-items-center mb-10">
                <div class="border-bottom border-gray-300 mw-50 w-100"></div>
                <span class="fw-bold text-gray-400 fs-7 mx-2">OR</span>
                <div class="border-bottom border-gray-300 mw-50 w-100"></div>
              </div>
              <!--end::Separator-->
              <?php } ?>
              <!--begin::Input group-->
              <div class="fv-row mb-7">
                <label class="form-label fw-bolder text-dark fs-6">昵称</label>
                <input v-model="user.name" class="form-control form-control-lg form-control-solid" type="text" placeholder="请输入昵称"
                  name="nickname" autocomplete="off">
              </div>
              <!--end::Input group-->
              <!--begin::Input group-->
              <div class="fv-row mb-7">
                <label class="form-label fw-bolder text-dark fs-6">账号</label>
                <input v-model="user.account" class="form-control form-control-lg form-control-solid" type="text" placeholder="请输入账号（建议使用QQ号码）"
                  name="account" autocomplete="off">
              </div>
              <!--end::Input group-->
              <!--begin::Input group-->
              <div class="mb-10 fv-row" data-kt-password-meter="true">
                <!--begin::Wrapper-->
                <div class="mb-1">
                  <!--begin::Label-->
                  <label class="form-label fw-bolder text-dark fs-6">密码</label>
                  <!--end::Label-->
                  <!--begin::Input wrapper-->
                  <div class="position-relative mb-3">
                    <input v-model="user.pass" class="form-control form-control-lg form-control-solid" type="password" placeholder="请输入密码"
                      name="password" autocomplete="off">
                    <span class="btn btn-sm btn-icon position-absolute translate-middle top-50 end-0 me-n2"
                      data-kt-password-meter-control="visibility">
                      <i class="bi bi-eye-slash fs-2"></i>
                      <i class="bi bi-eye fs-2 d-none"></i>
                    </span>
                  </div>
                  <!--end::Input wrapper-->
                  <!--begin::Meter-->
                  <div class="d-flex align-items-center mb-3" data-kt-password-meter-control="highlight">
                    <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                    <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                    <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                    <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px"></div>
                  </div>
                  <!--end::Meter-->
                </div>
                <!--end::Wrapper-->
                <!--begin::Hint-->
                <div class="text-muted">请输入 8 - 15 位密码，密码可包含数字、字母大小写及英文符号.</div>
                <!--end::Hint-->
              </div>
              <!--end::Input group=-->
              <!--begin::Input group-->
              <div class="fv-row mb-5">
                <label class="form-label fw-bolder text-dark fs-6">确认密码</label>
                <input class="form-control form-control-lg form-control-solid" type="password" placeholder="请再次输入密码"
                  name="confirm-password" autocomplete="off">
              </div>
              <!--end::Input group-->
              <!--begin::Input group-->
              <div class="fv-row mb-5">
                <label class="form-label fw-bolder text-dark fs-6">邀请码</label>
                <input v-model="user.yqm" class="form-control form-control-lg form-control-solid" type="text" placeholder="请输入邀请码"
                  name="yqm" autocomplete="off">
              </div>
              <!--end::Input group-->
              <!--begin::Input group-->
              <div class="fv-row mb-10">
                <label class="form-check form-check-custom form-check-inline form-check-solid">
                  <input class="form-check-input" type="checkbox" name="toc" value="1">
                  <span class="form-check-label fw-bold text-gray-700 fs-6">我接受 &amp;
                    <a href="JavaScript:;" class="ms-1 link-primary">爱学习用户协议</a>.</span>
                </label>
              </div>
              <!--end::Input group-->
              <!--begin::Actions-->
              <div class="text-center">
                <button type="button" id="kt_sign_up_submit" class="btn btn-lg btn-primary">
                  <span class="indicator-label">点击注册</span>
                  <span class="indicator-progress">Please wait...
                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                </button>
              </div>
              <!--end::Actions-->
            </form>
            <!--end::Form-->
          </div>
          <!--end::Wrapper-->
        </div>
        <!--end::Content-->
        <!--begin::Footer-->
        <div class="d-flex flex-center flex-wrap fs-6 p-5 pb-0">
          <!--begin::Links-->
          <div class="d-flex flex-center fw-bold fs-6">
            <a href="javascript:;" class="text-muted text-hover-primary px-2">Copyright © 2023 <?=$conf['sitename']?></a>
          </div>
          <!--end::Links-->
        </div>
        <!--end::Footer-->
      </div>
      <!--end::Body-->
    </div>
    <!--end::Authentication - Sign-up-->
  </div>
  <!--end::Main-->
  <!--begin::Javascript-->
  <!--begin::Global Javascript Bundle(used by all pages)-->
  <script src="static/js/plugins.bundle.js"></script>
  <script src="static/js/scripts.bundle.js"></script>
  <!--end::Global Javascript Bundle-->
  <!-- main - 开始 -->
  <script src="static/main/vue.min.js"></script>
  <script src="static/main/vue-resource.min.js"></script>
  <script src="static/main/axios.min.js"></script>
  <!-- main - 结束 -->
  <!--begin::Page Custom Javascript(used by this page)-->
  <script src="static/js/reg.js"></script>
  <!--end::Page Custom Javascript-->
  <!--end::Javascript-->
  <script src="static/utils/index.js"></script>
</body>
<!--end::Body-->

</html>