<!DOCTYPE html>
<html lang="zh">
<?php $pagename="系统设置"; ?>
<!-- 头部 - 开始 -->
<?php
require_once('./head.php');
if($userrow['uid']!=1){exit("<script language='javascript'>window.location.href='./404';</script>");}
?>
<!-- 头部 - 结束 -->

<!--begin::Body-->
<body id="kt_body"
  class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled aside-fixed aside-default-enabled">

  <!--begin::Root-->
  <div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="page d-flex flex-row flex-column-fluid">
      <!--侧边栏 - 开始-->
      <?php include('./aside.php'); ?>
      <!--侧边栏 - 结束-->
      <!--begin::Wrapper-->
      <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
        <!--页面头部 - 开始-->
        <?php include('./header.php'); ?>
        <!--页面头部 - 结束-->
        <!--页面主内容 - 开始-->
        <div class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
          <!--begin::Post-->
          <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div id="webset" class="container-xxl">
              <!--begin::Card-->
              <div class="card card-flush pb-0 bgi-position-y-center bgi-no-repeat mb-10" style="background-size: auto calc(100% + 10rem); background-position-x: 100%; background-image: url('static/image/4.png')">
                <!--begin::Card header-->
                <div class="card-header pt-10">
                  <div class="d-flex align-items-center">
                    <!--begin::Icon-->
                    <div class="symbol symbol-circle me-5">
                      <div class="symbol-label bg-transparent text-primary border border-secondary border-dashed">
                        <!--begin::Svg Icon | path: icons/duotune/abstract/abs020.svg-->
                        <span class="svg-icon svg-icon-2x svg-icon-primary">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                            <path d="M17.302 11.35L12.002 20.55H21.202C21.802 20.55 22.202 19.85 21.902 19.35L17.302 11.35Z" fill="black"></path>
                            <path opacity="0.3" d="M12.002 20.55H2.802C2.202 20.55 1.80202 19.85 2.10202 19.35L6.70203 11.45L12.002 20.55ZM11.302 3.45L6.70203 11.35H17.302L12.702 3.45C12.402 2.85 11.602 2.85 11.302 3.45Z" fill="black"></path>
                          </svg>
                        </span>
                        <!--end::Svg Icon-->
                      </div>
                    </div>
                    <!--end::Icon-->
                    <!--begin::Title-->
                    <div class="d-flex flex-column">
                      <h2 class="mb-1">系统设置</h2>
                      <div class="text-muted fw-bolder">
                      <a href="javascript:;">Good Morning</a>
                      <span class="mx-3">|</span>欢迎使用爱学习系统</div>
                    </div>
                    <!--end::Title-->
                  </div>
                </div>
                <!--end::Card header-->
                <!--begin::Card body-->
                <div class="card-body pb-0">
                  <!--begin::Navs-->
                  <div class="d-flex h-55px">
                    <ul class="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bold flex-nowrap">
                      <!--begin::Nav item-->
                      <li class="nav-item">
                        <a class="nav-link text-active-primary me-6 active" data-bs-toggle="tab" href="#tab_1">网站配置</a>
                      </li>
                      <!--end::Nav item-->
                      <!--begin::Nav item-->
                      <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" data-bs-toggle="tab" href="#tab_2">代理配置</a>
                      </li>
                      <!--end::Nav item-->
                      <!--begin::Nav item-->
                      <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" data-bs-toggle="tab" href="#tab_3">支付配置</a>
                      </li>
                      <!--end::Nav item-->
                      <!--begin::Nav item-->
                      <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" data-bs-toggle="tab" href="#tab_4">聚合登录</a>
                      </li>
                      <!--end::Nav item-->
                      <!--begin::Nav item-->
                      <li class="nav-item">
                        <a class="nav-link text-active-primary me-6" data-bs-toggle="tab" href="#tab_5">分类配置</a>
                      </li>
                      <!--end::Nav item-->
                    </ul>
                  </div>
                  <!--begin::Navs-->
                </div>
                <!--end::Card body-->
              </div>
              <!--end::Card-->
              <!--begin::Card-->
              <div class="card card-flush">
                <!--begin::Card body-->
                <div class="card-body">
                  <!--begin::Form-->
                  <form class="tab-content" id="form-web">
                    <!-- 网站配置 - 开始 -->
                    <div class="tab-pane fade active show" id="tab_1" role="tabpanel">
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">站点名称</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="sitename" class="form-control form-control-lg form-control-solid" placeholder="请输入站点名称" value="<?=$conf['sitename']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">站点关键词</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="keywords" class="form-control form-control-lg form-control-solid" placeholder="请输入站点关键词" value="<?=$conf['keywords']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">站点描述</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="description" class="form-control form-control-lg form-control-solid" placeholder="请输入站点描述" value="<?=$conf['description']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">站点LOGO地址</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="logo" class="form-control form-control-lg form-control-solid" placeholder="请输入站点LOGO地址" value="<?=$conf['logo']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">站点公告</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<textarea name="notice" class="form-control form-control-solid" rows="3" placeholder="支持HTML文本"><?=$conf['notice']?></textarea>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">站点弹窗</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<textarea name="tcgonggao" class="form-control form-control-solid" rows="3" placeholder="支持HTML文本"><?=$conf['tcgonggao']?></textarea>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">是否开启水印</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<select name="sykg" data-control="select2" data-placeholder="请选择是否开启水印..." class="form-select form-select-solid mb-2" data-hide-search="true">
                            <option value="1" <?php if($conf['sykg']==1){ echo 'selected';}?>>开启</option>
                            <option value="0" <?php if($conf['sykg']==0){ echo 'selected';}?>>关闭</option>
													</select>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                    </div>
                    <!-- 网站配置 - 结束 -->
                    <!-- 代理配置 - 开始 -->
                    <div class="tab-pane fade" id="tab_2" role="tabpanel">
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">代理开通价格</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="user_ktmoney" class="form-control form-control-lg form-control-solid" placeholder="请输入代理开通价格" value="<?=$conf['user_ktmoney']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">是否开启上级迁移功能</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<select name="sjqykg" data-control="select2" data-placeholder="请选择是否开启上级迁移功能..." class="form-select form-select-solid mb-2" data-hide-search="true">
                            <option value="1" <?php if($conf['sjqykg']==1){ echo 'selected';}?>>开启</option>
                            <option value="0" <?php if($conf['sjqykg']==0){ echo 'selected';}?>>关闭</option>
													</select>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">是否允许邀请码注册</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<select name="user_yqzc" data-control="select2" data-placeholder="请选择是否允许邀请码注册..." class="form-select form-select-solid mb-2" data-hide-search="true">
                            <option value="1" <?php if($conf['user_yqzc']==1){ echo 'selected';}?>>允许</option>
                            <option value="0" <?php if($conf['user_yqzc']==0){ echo 'selected';}?>>拒绝</option>
													</select>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">是否允许后台开户</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<select name="user_htkh" data-control="select2" data-placeholder="请选择是否允许后台开户..." class="form-select form-select-solid mb-2" data-hide-search="true">
                            <option value="1" <?php if($conf['user_htkh']==1){ echo 'selected';}?>>允许</option>
                            <option value="0" <?php if($conf['user_htkh']==0){ echo 'selected';}?>>拒绝</option>
													</select>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                    </div>
                    <!-- 代理配置 - 结束 -->
                    <!-- 支付配置 - 开始 -->
                    <div class="tab-pane fade" id="tab_3" role="tabpanel">
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">易支付API</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="epay_api" class="form-control form-control-lg form-control-solid" placeholder="例如：http://www.baidu.com/" value="<?=$conf['epay_api']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">商户ID</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="epay_pid" class="form-control form-control-lg form-control-solid" placeholder="请输入商户ID" value="<?=$conf['epay_pid']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">商户KEY</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="epay_key" class="form-control form-control-lg form-control-solid" placeholder="请输入商户KEY" value="<?=$conf['epay_key']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">最低充值金额</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="zdpay" class="form-control form-control-lg form-control-solid" placeholder="请输入最低充值金额" value="<?=$conf['zdpay']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">是否开启QQ支付</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<select name="is_qqpay" data-control="select2" data-placeholder="请选择是否开启QQ支付..." class="form-select form-select-solid mb-2" data-hide-search="true">
                            <option value="1" <?php if($conf['is_qqpay']==1){ echo 'selected';}?>>开启</option>
                            <option value="0" <?php if($conf['is_qqpay']==0){ echo 'selected';}?>>关闭</option>
													</select>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">是否开启微信支付</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<select name="is_wxpay" data-control="select2" data-placeholder="请选择是否开启微信支付..." class="form-select form-select-solid mb-2" data-hide-search="true">
                            <option value="1" <?php if($conf['is_wxpay']==1){ echo 'selected';}?>>开启</option>
                            <option value="0" <?php if($conf['is_wxpay']==0){ echo 'selected';}?>>关闭</option>
													</select>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">是否开启支付宝支付</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<select name="is_alipay" data-control="select2" data-placeholder="请选择是否允许后台开户..." class="form-select form-select-solid mb-2" data-hide-search="true">
                            <option value="1" <?php if($conf['is_alipay']==1){ echo 'selected';}?>>开启</option>
                            <option value="0" <?php if($conf['is_alipay']==0){ echo 'selected';}?>>关闭</option>
													</select>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                    </div>
                    <!-- 支付配置 - 结束 -->
                    <!-- 聚合登录 - 开始 -->
                    <div class="tab-pane fade" id="tab_4" role="tabpanel">
											<!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">是否开启快捷登录</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<select name="login_kg" data-control="select2" data-placeholder="请选择是否开启快捷登录..." class="form-select form-select-solid mb-2" data-hide-search="true">
                            <option value="1" <?php if($conf['login_kg']==1){ echo 'selected';}?>>开启</option>
                            <option value="0" <?php if($conf['login_kg']==0){ echo 'selected';}?>>关闭</option>
													</select>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">彩虹聚合登录地址</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="login_apiurl" class="form-control form-control-lg form-control-solid" placeholder="请输入彩虹聚合登录地址" value="<?=$conf['login_apiurl']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">应用ID</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="login_appid" class="form-control form-control-lg form-control-solid" placeholder="请输入应用ID" value="<?=$conf['login_appid']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">应用KEY</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<input type="text" name="login_appkey" class="form-control form-control-lg form-control-solid" placeholder="请输入应用KEY" value="<?=$conf['login_appkey']?>">
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                    </div>
                    <!-- 聚合登录 - 结束 -->
                    <!-- 分类配置 - 开始 -->
                    <div class="tab-pane fade" id="tab_5" role="tabpanel">
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">是否开启分类</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<select name="flkg" data-control="select2" data-placeholder="请选择是否开启分类..." class="form-select form-select-solid mb-2" data-hide-search="true">
                            <option value="1" <?php if($conf['flkg']==1){ echo 'selected';}?>>开启</option>
                            <option value="0" <?php if($conf['flkg']==0){ echo 'selected';}?>>关闭</option>
													</select>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                      <!--begin::Input group-->
											<div class="fv-row row mb-6">
												<!--begin::Col-->
												<div class="col-md-3 d-flex align-items-center">
													<!--begin::Label-->
													<label class="fs-6 fw-bold">分类类型</label>
													<!--end::Label-->
												</div>
												<!--end::Col-->
												<!--begin::Col-->
												<div class="col-md-9">
													<!--begin::Input-->
													<select name="fllx" data-control="select2" data-placeholder="请选择分类类型..." class="form-select form-select-solid mb-2" data-hide-search="true">
                            <option value="0" <?php if($conf['fllx']==0){ echo 'selected';}?>>侧边栏分类</option>  
                            <option value="1" <?php if($conf['fllx']==1){ echo 'selected';}?>>下单页面选择框分类</option>
                            <option value="2" <?php if($conf['fllx']==2){ echo 'selected';}?>>下单页面单选框分类</option>
													</select>
													<!--end::Input-->
												</div>
												<!--end::Col-->
											</div>
											<!--end::Input group-->
                    </div>
                    <!-- 分类配置 - 结束 -->
										<!-- 保存按钮 - 开始 -->
										<div class="card-footer d-flex justify-content-end py-6" style="padding-right:0px;">
											<button id="saveBtn" type="button" class="btn btn-primary" @click="handleSave">
												<span class="indicator-label">确认保存</span>
												<span class="indicator-progress">Please wait... 
												<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
											</button>
										</div>
										<!-- 保存按钮 - 结束 -->
                  </form>
                  <!--end::Form-->
                </div>
                <!--end::Card body-->
              </div>
              <!--end::Card-->
            </div>
            <!--end::Container-->
          </div>
          <!--end::Post-->
        </div>
        <!--页面主内容 - 结束-->
        <!--页面底部 - 开始-->
        <?php include('./footer.php'); ?>
        <!--页面底部 - 结束-->
      </div>
      <!--end::Wrapper-->
    </div>
    <!--end::Page-->
  </div>
  <!--end::Root-->
  <!-- 底部 - 开始 -->
  <?php require_once('./foot.php'); ?>
  <!-- 底部 - 结束 -->
  <!-- 本页面需要 - 开始 -->
  <script src="static/main/pages/webset.js"></script>
  <!-- 本页面需要 - 结束 -->
</body>
<!--end::Body-->
</html>