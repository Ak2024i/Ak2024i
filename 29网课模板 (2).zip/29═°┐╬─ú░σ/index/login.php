<?php
include('../confing/common.php');
?>
<!DOCTYPE html>
<html lang="zh">
<!--begin::Head-->

<head>
  <title>用户登录 –
    <?=$conf['sitename']?>
  </title>
  <meta charset="utf-8" />
  <meta name="description" content="<?=$conf['description'];?>" />
  <meta name="keywords" content="<?=$conf['keywords'];?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="shortcut icon" href="<?=$conf['logo'];?>" />
  <!--begin::Fonts-->
  <link rel="stylesheet" href="static/css/css.css" />
  <!--end::Fonts-->
  <!--begin::Global Stylesheets Bundle(used by all pages)-->
  <link href="static/css/plugins.bundle.css" rel="stylesheet" type="text/css" />
  <link href="static/css/style.bundle.css" rel="stylesheet" type="text/css" />
  <script src="static/main/unc.js"></script>
  <!--end::Global Stylesheets Bundle-->
</head>
<!--end::Head-->
<!--begin::Body-->

<body id="kt_body" class="auth-bg">
  <!--begin::Main-->
  <div id="login" class="d-flex flex-column flex-root">
    <!--begin::Authentication - Sign-in -->
    <div class="d-flex flex-column flex-lg-row flex-column-fluid">
      <!--begin::Aside-->
      <div class="d-flex flex-column flex-lg-row-auto bg-primary w-xl-600px positon-xl-relative">
        <!--begin::Wrapper-->
        <div class="d-flex flex-column position-xl-fixed top-0 bottom-0 w-xl-600px scroll-y">
          <!--begin::Header-->
          <div class="d-flex flex-row-fluid flex-column text-center p-10 pt-lg-20">
            <!--begin::Logo-->
            <a href="javascript:;" class="py-9 pt-lg-20">
              <img alt="Logo" src="static/picture/logo-ellipse.svg" class="h-70px" />
            </a>
            <!--end::Logo-->
            <!--begin::Title-->
            <h1 class="fw-bolder text-white fs-2qx pb-5 pb-md-10">
              欢迎使用爱学习
            </h1>
            <!--end::Title-->
            <!--begin::Description-->
            <p class="fw-bold fs-2 text-white">
              Plan your blog post by choosing a topic creating <br />an
              outline and checking facts
            </p>
            <!--end::Description-->
          </div>
          <!--end::Header-->
          <!--begin::Illustration-->
          <div
            class="d-flex flex-row-auto bgi-no-repeat bgi-position-x-center bgi-size-contain bgi-position-y-bottom min-h-100px min-h-lg-350px"
            style="background-image: url(static/image/17.png)"></div>
          <!--end::Illustration-->
        </div>
        <!--end::Wrapper-->
      </div>
      <!--begin::Aside-->
      <!--begin::Body-->
      <div class="d-flex flex-column flex-lg-row-fluid py-10">
        <!--begin::Content-->
        <div class="d-flex flex-center flex-column flex-column-fluid">
          <!--begin::Wrapper-->
          <div class="w-lg-500px p-10 p-lg-15 mx-auto">
            <!--begin::Form-->
            <form class="form w-100" novalidate="novalidate" id="kt_sign_in_form" action="#">
              <!--begin::Heading-->
              <div class="text-center mb-10">
                <!--begin::Title-->
                <h1 class="text-dark mb-3">用户登录</h1>
                <!--end::Title-->
                <!--begin::Link-->
                <div class="text-gray-400 fw-bold fs-4">
                  还没有账户?
                  <a href="./reg" class="link-primary fw-bolder">点击注册</a>
                </div>
                <!--end::Link-->
              </div>
              <!--begin::Heading-->
              <!--begin::Input group-->
              <div class="fv-row mb-10">
                <!--begin::Label-->
                <label class="form-label fs-6 fw-bolder text-dark">账号</label>
                <!--end::Label-->
                <!--begin::Input-->
                <input v-model="user.account" class="form-control form-control-lg form-control-solid" name="account"
                  type="text" autocomplete="off" placeholder="请输入账号" />
                <!--end::Input-->
              </div>
              <!--end::Input group-->
              <!--begin::Input group-->
              <div class="fv-row mb-10">
                <!--begin::Wrapper-->
                <div class="d-flex flex-stack mb-2">
                  <!--begin::Label-->
                  <label class="form-label fw-bolder text-dark fs-6 mb-0">密码</label>
                  <!--end::Label-->
                  <!--begin::Link-->
                  <a id="repassword" href="javascript:;" class="link-primary fs-6 fw-bolder">忘记密码 ?</a>
                  <!--end::Link-->
                </div>
                <!--end::Wrapper-->
                <!--begin::Input-->
                <input v-model="user.pass" class="form-control form-control-lg form-control-solid" name="password"
                  type="password" autocomplete="off" placeholder="请输入密码" />
                <!--end::Input-->
              </div>
              <!--end::Input group-->
              <!--begin::Actions-->
              <div class="text-center">
                <!--begin::Submit button-->
                <button type="submit" id="kt_sign_in_submit" class="btn btn-lg btn-primary fw-bolder me-3 my-2">
                  <span class="indicator-label">点击登录</span>
                  <span class="indicator-progress">Please wait...
                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                </button>
                <!--end::Submit button-->
                <?php if($conf['login_kg']==1){ ?>
                <!--begin::Google link-->
                <a id="connect_qq" href="javascript:;" class="btn btn-light-primary btn-lg fw-bolder my-2">
                  <img alt="Logo" style="height: 24px !important" src="static/picture/qq-icon.svg"
                    class="h-20px me-3" />快捷登录</a>
                <!--end::Google link-->
                <?php } ?>
              </div>
              <!--end::Actions-->
            </form>
            <!--end::Form-->
          </div>
          <!--end::Wrapper-->
        </div>
        <!--end::Content-->
        <!--begin::Footer-->
        <div class="d-flex flex-center flex-wrap fs-6 p-5 pb-0">
          <!--begin::Links-->
          <div class="d-flex flex-center fw-bold fs-6">
            <a href="javascript:;" class="text-muted text-hover-primary px-2">Copyright © 2023
              <?=$conf['sitename']?>
            </a>
          </div>
          <!--end::Links-->
        </div>
        <!--end::Footer-->
      </div>
      <!--end::Body-->
    </div>
    <!--end::Authentication - Sign-in-->
    <!--管理员认证弹窗 - 开始-->
    <div class="modal fade" id="modal_auth" tabindex="-1" aria-hidden="true">
      <!--begin::Modal dialog-->
      <div class="modal-dialog modal-dialog-centered mw-650px">
        <!--begin::Modal content-->
        <div class="modal-content">
          <!--begin::Modal header-->
          <div class="modal-header">
            <!--begin::Modal title-->
            <h3 class="fw-boldest text-dark fs-1 mb-0">管理员认证</h3>
            <!--end::Modal title-->
            <!--begin::Close-->
            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
              <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
              <span class="svg-icon svg-icon-2x">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                  <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)"
                    fill="black"></rect>
                  <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black">
                  </rect>
                </svg>
              </span>
              <!--end::Svg Icon-->
            </div>
            <!--end::Close-->
          </div>
          <!--end::Modal header-->
          <!--begin::Modal body-->
          <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
            <!--begin::Form-->
            <form class="form" action="#" @submit.prevent="">
              <!--begin::Input group-->
              <div class="d-flex flex-column mb-7 fv-row">
                <input id="authInput" v-model="authPass" @keyup.enter="login2()" type="text"
                  class="form-control form-control-solid" placeholder="请输入认证密码" autocomplete="off">
              </div>
              <!--end::Input group-->
              <!--begin::Actions-->
              <div class="text-center pt-15">
                <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">取消</button>
                <button id="authloginbtn" type="button" class="btn btn-primary" @click="login2()"><span
                    class="indicator-label">确认提交</span>
                  <span class="indicator-progress">Please wait...
                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span></button>
              </div>
              <!--end::Actions-->
            </form>
            <!--end::Form-->
          </div>
          <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
      </div>
      <!--end::Modal dialog-->
    </div>
    <!--管理员认证弹窗 - 结束-->
  </div>
  <!--end::Main-->
  <!--begin::Javascript-->
  <!--begin::Global Javascript Bundle(used by all pages)-->
  <script src="static/js/plugins.bundle.js"></script>
  <script src="static/js/scripts.bundle.js"></script>
  <!--end::Global Javascript Bundle-->
  <!-- main - 开始 -->
  <script src="static/main/vue.min.js"></script>
  <script src="static/main/vue-resource.min.js"></script>
  <script src="static/main/axios.min.js"></script>
  <!-- main - 结束 -->
  <!--begin::Page Custom Javascript(used by this page)-->
  <script src="static/js/login.js"></script>
  <!--end::Page Custom Javascript-->
  <!--end::Javascript-->
  <script src="static/utils/index.js"></script>
  <script src="static/utils/toast.js"></script>
  <script>
    document.querySelector('#repassword').addEventListener('click', function () {
      Swal.fire({
        text: '请联系你的上级进行密码重置！',
        icon: 'warning',
        buttonsStyling: !1,
        confirmButtonText: '确认',
        customClass: { confirmButton: 'btn btn-primary' },
      })
    })
  </script>
</body>
<!--end::Body-->

</html>