<!DOCTYPE html>
<html lang="zh">
<?php $pagename="平台对接" ?>
<!-- 头部 - 开始 -->
<?php require_once('./head.php'); ?>
<!-- 头部 - 结束 -->

<!--begin::Body-->

<body id="kt_body"
  class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled aside-fixed aside-default-enabled">

  <!--begin::Root-->
  <div class="d-flex flex-column flex-root">
    <!--begin::Page-->
    <div class="page d-flex flex-row flex-column-fluid">
      <!--侧边栏 - 开始-->
      <?php include('./aside.php'); ?>
      <!--侧边栏 - 结束-->
      <!--begin::Wrapper-->
      <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
        <!--页面头部 - 开始-->
        <?php include('./header.php'); ?>
        <!--页面头部 - 结束-->
        <!--页面主内容 - 开始-->
        <div class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
          <!--begin::Toolbar-->
          <div class="toolbar" id="kt_toolbar">
            <div class="container-fluid d-flex flex-stack flex-wrap flex-sm-nowrap">
              <!--begin::Info-->
              <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                <!--begin::Title-->
                <h1 class="text-dark fw-bolder my-1 fs-2"><?php echo $pagename ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb fw-bold fs-base my-1">
                  <li class="breadcrumb-item text-muted">
                    <a href="./index" class="text-muted text-hover-primary">首页</a>
                  </li>
                  <li class="breadcrumb-item text-muted">用户中心</li>
                  <li class="breadcrumb-item text-dark"><?php echo $pagename ?></li>
                </ul>
                <!--end::Breadcrumb-->
              </div>
              <!--end::Info-->
              <!--begin::Actions-->
              <div class="d-flex align-items-center flex-nowrap text-nowrap py-1">
                <a href="JavaScript:;" class="btn bg-body btn-color-gray-700 btn-active-primary me-4" data-bs-toggle="modal" data-bs-target="#modal_usernotice">站点公告</a>
                <a href="JavaScript:;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_tcgonggao">重要通知</a>
              </div>
              <!--end::Actions-->
            </div>
          </div>
          <!--end::Toolbar-->
          <!--begin::Post-->
          <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div class="container-xxl">
              <!--begin::Card-->
              <div class="card card-bordered">
                <div class="card-body">
                  <div class="row mb-1">
                    <!--begin::Label-->
                    <label class="col-lg-1 col-form-label fw-bold fs-6">对接地址</label>
                    <!--end::Label-->
                    <!--begin::Col-->
                    <div class="col-lg-11 d-flex">
                      <input class="form-control form-control-solid mb-3 mb-lg-0 me-5" type="text" id="kt_clipboard_4" value="http://<?echo($_SERVER['SERVER_NAME']);?>/api.php?act=add">
                      <!--begin::Button-->
                      <button class="btn btn-icon btn-light" data-clipboard-target="#kt_clipboard_4">
                        <span class="svg-icon svg-icon-2">
                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path opacity="0.5" d="M18 2H9C7.34315 2 6 3.34315 6 5H8C8 4.44772 8.44772 4 9 4H18C18.5523 4 19 4.44772 19 5V16C19 16.5523 18.5523 17 18 17V19C19.6569 19 21 17.6569 21 16V5C21 3.34315 19.6569 2 18 2Z" fill="black"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M14.7857 7.125H6.21429C5.62255 7.125 5.14286 7.6007 5.14286 8.1875V18.8125C5.14286 19.3993 5.62255 19.875 6.21429 19.875H14.7857C15.3774 19.875 15.8571 19.3993 15.8571 18.8125V8.1875C15.8571 7.6007 15.3774 7.125 14.7857 7.125ZM6.21429 5C4.43908 5 3 6.42709 3 8.1875V18.8125C3 20.5729 4.43909 22 6.21429 22H14.7857C16.5609 22 18 20.5729 18 18.8125V8.1875C18 6.42709 16.5609 5 14.7857 5H6.21429Z" fill="black"></path>
                          </svg>
                        </span>
                      </button>
                      <!--end::Button-->
                    </div>
                    <!--end::Col-->
                  </div>
                </div>
              </div>
              <!--end::Card-->
              <div class="col-xxl-12 mt-6">
                <!--begin:Row-->
                <div class="row g-xl-8">
                  <!--begin:Col-->
                  <div class="col-xl-6">
                    <!--begin::Stats Widget 3-->
                    <div class="card card-xl-stretch mb-5 mb-xl-8">
                      <!--begin::Body-->
                      <div class="card-body">
                        <!--begin::Section-->
                        <div class="d-flex align-items-center">
                          <!--begin::Symbol-->
                          <div class="symbol symbol-50px me-5">
                            <span class="symbol-label bg-light-info">
                              <!--begin::Svg Icon | path: icons/duotune/communication/com012.svg-->
                              <span class="svg-icon svg-icon-2qx svg-icon-info">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                  <path opacity="0.3" d="M20 3H4C2.89543 3 2 3.89543 2 5V16C2 17.1046 2.89543 18 4 18H4.5C5.05228 18 5.5 18.4477 5.5 19V21.5052C5.5 22.1441 6.21212 22.5253 6.74376 22.1708L11.4885 19.0077C12.4741 18.3506 13.6321 18 14.8167 18H20C21.1046 18 22 17.1046 22 16V5C22 3.89543 21.1046 3 20 3Z" fill="black"></path>
                                  <rect x="6" y="12" width="7" height="2" rx="1" fill="black"></rect>
                                  <rect x="6" y="7" width="12" height="2" rx="1" fill="black"></rect>
                                </svg>
                              </span>
                              <!--end::Svg Icon-->
                            </span>
                          </div>
                          <!--end::Symbol-->
                          <!--begin::Title-->
                          <div>
                            <a href="JavaScript:;" class="fs-4 text-gray-800 text-hover-primary fw-boldest">无需kcid的课：</a>
                            <!-- <div class="fs-7 text-muted fw-bold mt-1">数据仅供参考</div> -->
                          </div>
                          <!--end::Title-->
                        </div>
                        <!--end::Section-->
                        <!--begin::stats-->
                        <p style="font-size:25px">uid|你的对接UID<br/>
                            key|你的对接KEY<br/>
                            platform|平台课程ID<br/>
                            user|[input1]<br/>
                            pass|[input2]<br/>
                            school|[input3]<br/>
                            kcname|[input4]<br/>
                        </p>
                        <!--end::stats-->
                      </div>
                      <!--end::Body-->
                    </div>
                    <!--end::Stats Widget 3-->
                  </div>
                  <!--end:Col-->
                  <!--begin:Col-->
                  <div class="col-xl-6">
                    <!--begin::Stats Widget 4-->
                    <div class="card card-xl-stretch mb-5 mb-xl-8">
                      <!--begin::Body-->
                      <div class="card-body">
                        <!--begin::Section-->
                        <div class="d-flex align-items-center">
                          <!--begin::Symbol-->
                          <div class="symbol symbol-50px me-5">
                            <span class="symbol-label bg-light-danger">
                              <!--begin::Svg Icon | path: icons/duotune/general/gen025.svg-->
                              <span class="svg-icon svg-icon-2hx svg-icon-danger">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                  <rect x="2" y="2" width="9" height="9" rx="2" fill="black"></rect>
                                  <rect opacity="0.3" x="13" y="2" width="9" height="9" rx="2" fill="black"></rect>
                                  <rect opacity="0.3" x="13" y="13" width="9" height="9" rx="2" fill="black"></rect>
                                  <rect opacity="0.3" x="2" y="13" width="9" height="9" rx="2" fill="black"></rect>
                                </svg>
                              </span>
                              <!--end::Svg Icon-->
                            </span>
                          </div>
                          <!--end::Symbol-->
                          <!--begin::Title-->
                          <div>
                            <a href="JavaScript:;" class="fs-4 text-gray-800 text-hover-primary fw-boldest">需要kcid的课：</a>
                            <!-- <div class="fs-7 text-muted fw-bold mt-1">数据仅供参考</div> -->
                          </div>
                          <!--end::Title-->
                        </div>
                        <!--end::Section-->
                        <!--begin::stats-->
                        <p style="font-size:25px">uid|你的对接UID<br/>
                            key|你的对接KEY<br/>
                            platform|平台课程ID<br/>
                            user|[input1]<br/>
                            pass|[input2]<br/>
                            school|[input3]<br/>
                            kcid|[input4]<br/>
                            kcname|[input5]<br/>
                        </p>
                        <!--end::stats-->
                      </div>
                      <!--end::Body-->
                    </div>
                    <!--end::Stats Widget 4-->
                  </div>
                  <!--end:Col-->
                </div>
                <!--end:Row-->
              </div>
            </div>
            <!--end::Container-->
          </div>
          <!--end::Post-->
        </div>
        <!--页面主内容 - 结束-->
        <!--页面底部 - 开始-->
        <?php include('./footer.php'); ?>
        <!--页面底部 - 结束-->
      </div>
      <!--end::Wrapper-->
    </div>
    <!--end::Page-->
  </div>
  <!--end::Root-->
  <!-- 底部 - 开始 -->
  <?php require_once('./foot.php'); ?>
  <!-- 底部 - 结束 -->
  <!-- 本页面需要 - 开始 -->
  <script>
    // Select elements
    const target = document.getElementById('kt_clipboard_4');
    const button = target.nextElementSibling;

    // Init clipboard -- for more info, please read the offical documentation: https://clipboardjs.com/
    clipboard = new ClipboardJS(button, {
        target: target,
        text: function () {
            return target.innerHTML;
        }
    });

    // Success action handler
    clipboard.on('success', function (e) {
        var checkIcon = button.querySelector('.bi.bi-check-lg');
        var svgIcon = button.querySelector('.svg-icon');

        // Exit check icon when already showing
        if (checkIcon) {
            return;
        }

        // Create check icon
        checkIcon = document.createElement('i');
        checkIcon.classList.add('bi');
        checkIcon.classList.add('bi-check-lg');
        checkIcon.classList.add('fs-2x');

        // Append check icon
        button.appendChild(checkIcon);

        // Highlight target
        const classes = ['text-success', 'fw-boldest'];
        target.classList.add(...classes);

        // Highlight button
        button.classList.add('btn-success');

        // Hide copy icon
        svgIcon.classList.add('d-none');

        // Revert button label after 3 seconds
        setTimeout(function () {
            // Remove check icon
            svgIcon.classList.remove('d-none');

            // Revert icon
            button.removeChild(checkIcon);

            // Remove target highlight
            target.classList.remove(...classes);

            // Remove button highlight
            button.classList.remove('btn-success');
        }, 3000)
    });
  </script>
  <!-- 本页面需要 - 结束 -->
</body>
<!--end::Body-->

</html>